// import request from 'superagent';


export function getUrl() {
	if(process.env.NODE_ENV === 'production') {
		return "https://api.sysmocart.com/v1/"
	}
	else {
		return "https://api.sysmocart.com/v1/"
	}
}
