import React from 'react';
import { connect } from 'react-redux';
import { isMobile } from '../Helper/Common'
import { Link } from 'react-router-dom';
import { Carousel } from 'react-bootstrap';
import LazyLoad from 'react-lazy-load';
import { Helmet } from "react-helmet";
import Slider from "react-slick";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";



class Home extends React.Component {
    render() {
         const settings = {
          dots: false,
          arrows: true,
          infinite: false,
          speed: 500,
          lazyLoad: true,
          slidesToShow: 6,
          slidesToScroll: 6,
          initialSlide: 0,
          responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 5,
                slidesToScroll: 5,
                infinite: true,
                dots: true
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                initialSlide: 2,
                arrows: false,
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 4,
                arrows: false,
                slidesToScroll: 4
              }
            }
          ]
        };


        const settingsMain = {
          dots: true,
          infinite: true,
          speed: 500,
          lazyLoad: true,
          slidesToShow: 1,
          slidesToScroll: 1,
          initialSlide: 0
        };

        
        return(
            <div className={isMobile() ? null :'container fixed-top-margin'}>
                <div className="main" style={isMobile() ? {marginTop: 100} : null}>

                    <div className="row content_top" style={isMobile() ? {marginRight: 0, marginLeft: 0 } : null}>
                        <div style={isMobile() ? {padding: '15px 0px'} : {padding: '15px 40px'}}>
                            <Slider {...settings}>
                                  <Link className="top-small-slider" to="/Fruits-And-Vegetables">
                                    <img width="60" height="60" src="/static/1.jpg"></img>
                                    <div className="top-slider-text">Fruits And Vegetables</div>
                                  </Link>
                                  <Link className="top-small-slider" to="/Staples">
                                    <img width="60" height="60" src="/static/2.jpg"></img>
                                    <div className="top-slider-text">Staples</div>
                                  </Link>
                                  <Link className="top-small-slider" to="/Beverages">
                                    <img width="60" height="60" src="/static/3.jpg"></img>
                                    <div className="top-slider-text">Beverages</div>
                                  </Link>
                                  <Link className="top-small-slider" to="/Baby-Care">
                                    <img width="60" height="60" src="/static/4.jpg"></img>
                                    <div className="top-slider-text">Baby Care</div>
                                  </Link>
                                  <Link className="top-small-slider" to="/Home-Care">
                                    <img width="60" height="60" src="/static/6.jpg"></img>
                                    <div className="top-slider-text">Home Care</div>
                                  </Link>
                                  <Link className="top-small-slider" to="/Snacks-&-Branded-Foods">
                                    <img width="60" height="60" src="/static/11.jpg"></img>
                                    <div className="top-slider-text">Snacks & Branded Foods</div>
                                  </Link>
                                  <Link className="top-small-slider" to="/Personal-Care">
                                    <img width="60" height="60" src="/static/8.jpg"></img>
                                    <div className="top-slider-text">Personal Care</div>
                                  </Link>
                                  <Link className="top-small-slider" to="/Dairy-&-Bakery">
                                    <img width="60" height="60" src="/static/9.jpg"></img>
                                    <div className="top-slider-text">Dairy & Bakery</div>
                                  </Link>
                            </Slider>
                        </div>
                        <div className="col-md-12 content_left" style={{marginTop: 40}}>
                            <Slider {...settingsMain}>
                                  <a className="top-small-slider">
                                    <img src="/static/slider1.jpg" style={isMobile() ? {width: "100%"} : null}  />
                                  </a>
                                  <a className="top-small-slider">
                                    <img src="/static/slider2.jpg" style={isMobile() ? {width: "100%"} : null}  />
                                  </a>
                                  <a className="top-small-slider">
                                    <img src="/static/slider3.jpg" style={isMobile() ? {width: "100%"} : null}  />
                                  </a>
                                  <a className="top-small-slider">
                                    <img src="/static/slider4.jpg" style={isMobile() ? {width: "100%"} : null}  />
                                  </a>
                                  <a className="top-small-slider">
                                    <img src="/static/slider5.jpg" style={isMobile() ? {width: "100%"} : null}  />
                                  </a>
                            </Slider>
                        </div>
                        <div className="clearfix"></div>
                    </div>
                    <div className="content">
                        <div className="grids" style={isMobile() ? {marginRight: 0, marginLeft: 0 } : null}>
                          <div className="col-sm-12 list-items">
                            <Link className="hover-effect" to="/Snacks-&-Branded-Foods">
                              <div className="home-image">
                                  <img width="150" src="/static/a1.jpg"></img>
                              </div>
                              <div className="home-box" style={isMobile() ? {paddingRight: 0} : null}>
                                    <div className="home-dis">
                                      Up to 71% OFF
                                    </div>
                                    <div className="home-cat">
                                      Staples
                                    </div>
                                    <div className="home-des">
                                      Pulses, Atta & Other Flours, Rice & Other Grains, Dry Fruits & Nuts, Edible Oils, Ghee & Vanaspati, Spices, Salt & Sugar, Organic Staples
                                    </div>
                                </div>
                             </Link>
                          </div>
                           <div className="col-sm-12 list-items">
                           <Link className="hover-effect" to="Snacks-&-Branded-Foods">
                            <div className="home-image">
                                <img width="150" src="/static/a6.jpg"></img>
                            </div>
                              <div className="home-box" style={isMobile() ? {paddingRight: 0} : null}>
                                    <div className="home-dis">
                                      Up to 71% OFF
                                    </div>
                                    <div className="home-cat">
                                      Snacks & Branded Foods
                                    </div>
                                    <div className="home-des">
                                      Pulses, Atta & Other Flours, Rice & Other Grains, Dry Fruits & Nuts, Edible Oils, Ghee & Vanaspati, Spices, Salt & Sugar, Organic Staples
                                    </div>
                                </div>
                            </Link>
                          </div>
                           <div className="col-sm-12 list-items">
                           <Link className="hover-effect" to="Beverages">
                            <div className="home-image">
                                <img width="150" src="/static/a7.jpg"></img>
                            </div>
                              <div className="home-box" style={isMobile() ? {paddingRight: 0} : null}>
                                    <div className="home-dis">
                                      Up to 71% OFF
                                    </div>
                                    <div className="home-cat">
                                      Beverages
                                    </div>
                                    <div className="home-des">
                                      Pulses, Atta & Other Flours, Rice & Other Grains, Dry Fruits & Nuts, Edible Oils, Ghee & Vanaspati, Spices, Salt & Sugar, Organic Staples
                                    </div>
                                </div>
                            </Link>
                          </div>
                           <div className="col-sm-12 list-items">
                           <Link className="hover-effect" to="Dairy-&-Bakery">
                            <div className="home-image">
                                <img width="150" src="/static/a10.jpg"></img>
                            </div>
                              <div className="home-box" style={isMobile() ? {paddingRight: 0} : null}>
                                    <div className="home-dis">
                                      Up to 71% OFF
                                    </div>
                                    <div className="home-cat">
                                      Dairy & Bakery
                                    </div>
                                    <div className="home-des">
                                      Pulses, Atta & Other Flours, Rice & Other Grains, Dry Fruits & Nuts, Edible Oils, Ghee & Vanaspati, Spices, Salt & Sugar, Organic Staples
                                    </div>
                                </div>
                            </Link>
                          </div>
                           <div className="col-sm-12 list-items">
                           <Link className="hover-effect" to="Personal-Care">
                            <div className="home-image">
                                <img width="150" src="/static/a3.jpg"></img>
                            </div>
                              <div className="home-box" style={isMobile() ? {paddingRight: 0} : null}>
                                    <div className="home-dis">
                                      Up to 71% OFF
                                    </div>
                                    <div className="home-cat">
                                      Personal Care
                                    </div>
                                    <div className="home-des">
                                      Pulses, Atta & Other Flours, Rice & Other Grains, Dry Fruits & Nuts, Edible Oils, Ghee & Vanaspati, Spices, Salt & Sugar, Organic Staples
                                    </div>
                                </div>
                            </Link>
                          </div>
                           <div className="col-sm-12 list-items">
                           <Link className="hover-effect" to="Home-Care">
                            <div className="home-image">
                                <img width="150" src="/static/a9.jpg"></img>
                            </div>
                              <div className="home-box" style={isMobile() ? {paddingRight: 0} : null}>
                                    <div className="home-dis">
                                      Up to 71% OFF
                                    </div>
                                    <div className="home-cat">
                                      Home Care
                                    </div>
                                    <div className="home-des">
                                      Pulses, Atta & Other Flours, Rice & Other Grains, Dry Fruits & Nuts, Edible Oils, Ghee & Vanaspati, Spices, Salt & Sugar, Organic Staples
                                    </div>
                                </div>
                            </Link>
                          </div>
                           <div className="col-sm-12 list-items">
                           <Link className="hover-effect" to="Baby-Care">
                            <div className="home-image">
                                <img width="150" src="/static/a8.jpg"></img>
                            </div>
                              <div className="home-box" style={isMobile() ? {paddingRight: 0} : null}>
                                    <div className="home-dis">
                                      Up to 71% OFF
                                    </div>
                                    <div className="home-cat">
                                      Baby Care
                                    </div>
                                    <div className="home-des">
                                      Pulses, Atta & Other Flours, Rice & Other Grains, Dry Fruits & Nuts, Edible Oils, Ghee & Vanaspati, Spices, Salt & Sugar, Organic Staples
                                    </div>
                                </div>
                            </Link>
                          </div>
                           <div className="col-sm-12 list-items">
                           <Link className="hover-effect" to="Fruits-And-Vegetables">
                            <div className="home-image">
                                <img width="150" src="/static/a2.jpg"></img>
                            </div>
                              <div className="home-box" style={isMobile() ? {paddingRight: 0} : null}>
                                    <div className="home-dis">
                                      Up to 71% OFF
                                    </div>
                                    <div className="home-cat">
                                      Fruits And Vegetables
                                    </div>
                                    <div className="home-des">
                                      Pulses, Atta & Other Flours, Rice & Other Grains, Dry Fruits & Nuts, Edible Oils, Ghee & Vanaspati, Spices, Salt & Sugar, Organic Staples
                                    </div>
                                </div>
                            </Link>
                          </div>
                             
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        // filter: state.filter
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        // onFilter: filterText => dispatch(filterTable(filterText))
    };
};


export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Home);


