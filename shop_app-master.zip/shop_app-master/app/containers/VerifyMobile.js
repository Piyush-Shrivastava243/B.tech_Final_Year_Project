import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import VerifyMobileForm from '../components/VerifyMobileForm'
import { formValueSelector } from 'redux-form'
import Snackbar from 'material-ui/Snackbar';
import { reset } from 'redux-form';

import {cyan500, cyan700,  pinkA200,  grey100, grey300, grey400, grey500,  white, darkBlack, fullBlack,} from 'material-ui/styles/colors';


const muiTheme = getMuiTheme({
  palette: {
    textColor: darkBlack,
    alternateTextColor: white
  },
  appBar: {
    height: 50,
  },
});



class VerifyMobile extends React.Component {
	 state = {
	    stepIndex: 0,
	    counter: 0,
	    open: false,
	    message: 'Invalid OTP'
	  };

	  componentDidMount() {
	  	if(this.props.userData == null) {
	  		this.props.history.push("/login?next=/products");
	  	}
	  }

	  // componentWillReceiveProps(nextProps) {
	  // 	if(!this.props.isVerified && nextProps.isVerified) {
	  // 		this.props.history.push("/products");
	  // 	}
	  // }

	  handleNext = () => {
	    const {stepIndex} = this.state;
	    if (stepIndex < 1) {
	      this.startCount()
	      this.props.dispatch(actions.sendOTP())
	      this.setState({stepIndex: stepIndex + 1});
	    } else {

	    	this.props.dispatch(actions.mobileVerifyOTP(this.props.OTP, (res) => {
				if (!res.isOTPVerified) {
					this.setState({ open: true, message: 'Invalid OTP' });
					this.props.dispatch(reset('VerifyMobileForm'));
				} else {
					this.props.dispatch(actions.getuserData());
					this.props.history.push("/products");
				}
			}))
	    }
	  };

	startCount = ()=> {
	  	let counter = 60;
	    setInterval( ()=> {
	     counter--;
	      if (counter >= 0) {
	         this.setState({counter: counter});
	      }
	      if (counter === 0) {
	         clearInterval(counter);
	       }
	     }, 1000);
	}

	  handlePrev = () => {
	    const {stepIndex} = this.state;
	    if (stepIndex > 0) {
	      this.setState({stepIndex: stepIndex - 1});
	    }
	  };

    render() {
    	const {stepIndex, counter} = this.state;
    	const { userData, isOTPSending, OTPSent, isMobileVerifying } = this.props;
    	const mobile = userData && userData.data.mobile;
    	const isMobileVerified = userData && userData.data.mobileVerified;
        return(
             <div className="container fixed-top-margin">
             	<div className="login-main">
                    <div className="login-box">
                        <MuiThemeProvider muiTheme={muiTheme}>
                        	<div>
		                        {!isMobileVerified ? <VerifyMobileForm isMobileVerifying={isMobileVerifying}  isOTPSending={isOTPSending} OTPSent={OTPSent} counter={counter} mobile={mobile} stepIndex={stepIndex} handlePrev={this.handlePrev} handleNext={this.handleNext} /> :
		                        <span>Your primary mobile number <b>{mobile}</b> is already verified</span>
		                    	}

		                    	<Snackbar
						          open={this.state.open}
						          message={this.state.message}
						          autoHideDuration={3000}
						          onRequestClose={() => this.setState({ open: false })}
						        />
					        </div>
                        </MuiThemeProvider>
                    <div className="clearfix"></div>
                    </div>
                </div>
            </div>
        );
    }
}
const selector = formValueSelector('VerifyMobileForm');

function mapStateToProps(store){
    return {
    	userData: store.userLogin.loginUser,
    	isOTPSending: store.userLogin.isOTPSending,
    	OTPSent: store.userLogin.OTPSent,
    	OTP: selector(store, 'otp'),
    	isMobileVerifying: store.userLogin.isMobileVerifying,
		// isVerified: store.userLogin.isVerified,
		isLoggedIn: store.userLogin.isLoggedIn,
    }
}

export default connect(mapStateToProps)(VerifyMobile)
