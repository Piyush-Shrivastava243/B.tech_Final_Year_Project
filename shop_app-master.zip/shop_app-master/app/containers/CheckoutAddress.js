import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
import request from 'superagent';
import _ from 'lodash';
import Loadable from 'react-loading-overlay';
import { isMobile, validateCart } from '../Helper/Common';
import { FormControl, Modal } from 'react-bootstrap';
import FaEdit from 'react-icons/lib/fa/edit';
import FaClose from 'react-icons/lib/fa/close';
import FaPlus from 'react-icons/lib/fa/plus';
import swal from 'sweetalert'
import { Field, reduxForm, formValueSelector, change } from 'redux-form'
import * as types from '../actions/types';
import { PulseLoader } from 'react-spinners';
import { Image } from 'cloudinary-react';



const mobile = value =>
value && !/^\d{10}$/i.test(value) ?
'Invalid Email or Mobile' : undefined

const required = value => value ? undefined : 'This is a mandatory field';

const renderTextField = ({
	input,
	label,
	type,
	meta: { touched, error, warning }
}) => (
<div style={{fontSize: '12px'}}>
<input {...input} className="form-control" placeholder={label} type={type}  />
{touched &&
	((error && <span style={{color: '#ea6c6c'}}>{error}</span>) ||
		(warning && <span style={{color: '#ea6c6c'}}>{warning}</span>))}
	</div>
	
	)

const renderTextAreaField = ({
	input,
	label,
	type,
	meta: { touched, error, warning }
}) => (
<div style={{fontSize: '12px'}}>
<textarea  {...input} style={{resize: 'none'}} className="form-control" placeholder={label} type={type}  />
{touched &&
	((error && <span style={{color: '#ea6c6c'}}>{error}</span>) ||
		(warning && <span style={{color: '#ea6c6c'}}>{warning}</span>))}
	</div>
	)




class CheckoutAddress extends React.Component {

	state = {
		isPaymentLoading: false,
		open: false
	}

	componentWillMount() {
		if(!this.props.isLoggedIn) {
			this.props.history.push('/login?next=/checkout/address')
		}
	}

	componentDidMount() {
		this.props.dispatch(actions.getUserAddress())
	}

	handleAddressBox = (val)=> {
		// this.setState({addressBox: val})
		this.props.dispatch({type: types.SELECTED_ADDRESS, selectedAddress: val})

	}

	handleOpen = (val) => {
		this.props.dispatch({type: types.SELECTED_ADDRESS, selectedAddress: val})
		this.setState({open: true});
	};

	handleClose = () => {
		this.setState({open: false});
	};


	handleChange = (e)=> {
		const key = e.target.name;
		const val = e.target.value;
		this.setState({[key]: val})
	}


	handleAddress= (e)=> {
		const key = e.target.name;
		this.setState({checked: key})
	}


	validateCart = ()=> {
		const cartnew = this.props.cartProducts;
    let that = this;
    this.props.dispatch(actions.validateProducts(_.uniq(_.map(cartnew, 'productId')), ()=> {
      if(validateCart(that.props.cartProducts, that.props.liveCartItems)) {
        that.handlePayment();
      } else {
      	that.props.history.push("/checkout/cart")
        swal("Please remove out of stock items from your bag.");
      }   

    }))
	}

	handlePayment = ()=> {
		const addressId = this.props.selectedAddress;
		const products = this.props.cartProducts;

		let OrderDetails = [];

		for (let i =0; i<products.length; i++) {
			OrderDetails.push({
				ProductId: products[i].productId,
				Size: products[i].size,
				Quantity: products[i].qty,
				ProductName: products[i].Product.name,
				defaultImage: products[i].Product.default_image,
				addressId: addressId,
				Price: products[i].Product.discounted
			})
		}

		const jsonOrder = JSON.stringify(OrderDetails);

		this.setState({isPaymentLoading: true});
		this.props.dispatch(actions.handlePayment(jsonOrder, (res)=> {
			window.location = res.data;
		}));
	}

	saveAddressDetails = (values) => {
		if(this.props.selectedAddress !== null){
			this.props.dispatch(actions.updateUserAddress(values, this.props.selectedAddress, ()=> {
				this.props.dispatch(actions.getUserAddress())
				this.setState({open: false})

			}))
		} else {
			this.props.dispatch(actions.addUserAddress(values, ()=> {
				this.props.dispatch(actions.getUserAddress())
				this.setState({open: false})
			}))
		}

	}

	handleDelete = (val) => {
		swal({
			title: "Are you sure?",
			icon: "warning",
			buttons: true,
			dangerMode: true,
			buttons: ["Cancel", "Delete"]
		})
		.then((willDelete) => {
			if (willDelete) {
				this.props.dispatch(actions.deleteUserAddress(val, ()=> {
					this.props.dispatch(actions.getUserAddress())
				}))
			}
		});

	}

	onChangeHandle = (val)=> {
		if(val.length == 6){
			const apiKey= '579b464db66ec23bdd000001cdd3946e44ce4aad7209ff7b23ac571b'
			const api = `https://api.data.gov.in/resource/6176ee09-3d56-4a3b-8115-21841576b2f6?api-key=${apiKey}&format=json&filters[pincode]=${val}&limit=1`;
			request
			.get(api)
			.end( (err, res)=> {
				const data = res.body.records;
				if(data.length) {
					this.props.change('state', data[0].statename);
					this.props.change('city', data[0].districtname);
				} else {
					this.props.change('state', null);
					this.props.change('city', null)
				}
			});
		}
	}


	render() {
		const { Products, cartCount, cartProducts, userData, userAddress, selectedAddress, addressFetching } = this.props;
		const { handleSubmit } = this.props;

		let TotalPrice = 0;
		for(let i=0; i<cartProducts.length;i++){
			TotalPrice += (cartProducts[i].Product.discounted*cartProducts[i].qty);
		}


		return(
			<div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
			{ this.state.isPaymentLoading &&
				<Loadable
				active={true}
				spinner
				text='Loading Payment...'
				style={{position: 'fixed', right: 0, top: 0, left: 0, button: 0, height: '100%', zIndex: 99}}
				> 
				</Loadable>
			}
			<div className="main" style={isMobile() ? {padding: '10px'} : null}>
		{/*https://api.sysmocart.com/payment/pay.php*/}
		{addressFetching ? 
			<div style={{textAlign: '-webkit-center', minHeight: '600px'}}>
			<PulseLoader
			color={'#56bfea'} 
			loading={addressFetching} 
			/>
			</div>  :
			<div className="registration">
			<div className="col-md-7">
			<h2><span> Enter Delivery Information </span></h2>
			{userAddress && userAddress.map((data, index)=> {
				return(
					<div key={index} className={selectedAddress == data.id ?  'col-md-5 address-box active' : 'col-md-5 address-box'} onClick={()=> this.handleAddressBox(data.id)}>
						<div className="name-box">
							<button className="address-select"></button>
							<div className="name">{data.name}</div>
						</div>
						<div className="address-content" style={{paddingTop: '15px'}}>
							<span>{data.address}</span>
						</div>
						<div className="address-other">{data.city}, {data.pincode}</div>
							<div className="address-other">{data.state}</div>

							<div className="address-other" style={{paddingTop: '15px'}}>Mobile: <b>{data.mobile}</b></div>

						<div className="bottom-content">
							<FaEdit size={25} color="#9c9dab" onClick={()=> this.handleOpen(data.id)} />
							<FaClose size={25} color="#9c9dab" onClick={()=> this.handleDelete(data.id)} style={{float: 'right'}} />
						</div>
					</div>
					)
			})}
			<div className="col-md-5 address-box" style={{textAlign: 'center'}} onClick={()=> this.handleOpen(null)}>
			<div style={{padding: '20px'}}>Add New Address</div>
			<span style={{border: '2px solid #9c9dab', borderRadius: '50%', padding: '10px', marginTop: '30px'}}><FaPlus size={22} color="#9c9dab" /></span>
			</div>
			</div>
			<div className="col-md-5">
			<div className="registration_form">
			<div className="clearfix"></div>
			<ul className="list-group">
			{ 	cartProducts && cartProducts.map((data, index)=> {
				return(
					<li key={index} className="list-group-item" style={{fontSize: 15}}>
					<Image style={{marginRight: '5px'}} cloudName="sysmocart" publicId={data.defaultImage} width="30" crop="scale"/>
					{data.Product.name.substring(0,isMobile() ? 15 : 35)}{data.Product.name.length >=(isMobile() ? 15 : 35) && '...'} <b><small>({data.qty} Qty) | {data.size}</small></b><br />
					</li>
					)
			})}  
			<li className="list-group-item">
			<span>Delivery</span>
			<span style={{float: 'right'}}>Free</span>

			</li>
			<li className="list-group-item">
			<b>
			<span>Total Payable</span>
			<span style={{float: 'right'}}>Rs. {TotalPrice}</span>
			</b>
			</li>
			</ul>
			</div>
			<button disabled={this.state.isPaymentLoading || selectedAddress == null} onClick={this.validateCart} className="im-checkout-btn">{this.state.isPaymentLoading ? 'Please Wait..' : 'PAY NOW'}</button>

			</div>
			<div className="clearfix"></div>
			</div> }
			</div>

			<Modal show={this.state.open} onHide={this.handleClose}>
				<form onSubmit={handleSubmit(this.saveAddressDetails)}>
					<div className="registration address-select-box">
						<h2 style={{paddingLeft: '20px'}}><span> ADD NEW ADDRESS </span></h2>
						<div className="registration_form" style={{padding: '20px'}}>
							<div>
								<label className="two-fields" style={{display: 'flex'}}>
									<Field name="name" validate={[ required]} component={renderTextField} label="Name"/>
									<Field type="number" onChange={event => this.onChangeHandle(event.target.value)} name="pincode" validate={[ required ]}  component={renderTextField} label="Pin Code"/>
								</label>
							</div>
							<div>
								<label>
									<Field name="address" validate={[ required]}  component={renderTextAreaField} label="Address"/>
								</label>
							</div>
							<div>
							<label className="two-fields" style={{display: 'flex'}}>
								<Field name="state" validate={[ required]}  component={renderTextField} label="State"/>
								<Field name="city" validate={[ required]}  component={renderTextField} label="City"/>
							</label>
							</div>
							<div>
								<label>
									<Field name="mobile" validate={[ required]}  component={renderTextField} label="Mobile"/>
								</label>
							</div>
						</div>
					</div>
					<div style={{textAlign: 'center', padding: '0 0 15px'}}>
						<span className="btn btn-default" onClick={this.handleClose} style={{marginRight: 20}}>Cancel</span>
						<button className="btn btn-success" type="submit"style={{marginRight: 20}}>Save</button>
					</div>
				</form>
			</Modal>

			</div>
			);
}
}

const selector = formValueSelector('CheckoutAddress');

function mapStateToProps(store){
	let formVal = {}
	if(store.getProducts.userAddress.length){
		formVal = _.find(store.getProducts.userAddress, function(o) { return o.id == store.getProducts.selectedAddress; });
	}
	return {
		Products: store.getProducts.Products,
		cartCount: store.cart.cartCount,
		cartProducts: store.cart.cartProducts,
		isLoggedIn: store.userLogin.isLoggedIn,
		userData: store.userLogin.loginUser,
		userAddress: store.getProducts.userAddress,
		selectedAddress: store.getProducts.selectedAddress,
		initialValues: formVal,
		addressFetching: store.getProducts.addressFetching,
		pincode_value: selector(store, 'pincode'),
		liveCartItems: store.getProducts.liveCartItems,
	}
}


CheckoutAddress = reduxForm({
  form: 'CheckoutAddress', // a unique identifier for this form
  enableReinitialize: true
})(CheckoutAddress)


// You have to connect() to any reducers that you wish to connect to yourself
CheckoutAddress = connect(
	mapStateToProps
	)(CheckoutAddress)

	export default CheckoutAddress;
