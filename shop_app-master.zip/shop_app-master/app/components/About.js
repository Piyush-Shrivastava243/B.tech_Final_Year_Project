import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
import { isMobile } from '../Helper/Common';
// import * as actions from '../actions/types';


class About extends React.Component {
    render() {
        return(
            <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
                <div className="women_main" style={isMobile() ? {padding: '20px'} : null}>
                   <div className="row single">
                        <div className="col-md-12">
                            <h3>ABOUT US</h3>
                            <h4>Think Different, Think Custom!</h4>
                            <p>Welcome to SysmoCart &ndash; the India&rsquo;s new startup online grocery and more. Right Now we are serving our services to <b>Few Locations</b> only.</p>
                            <br />
                            <h4>Payment Option:</h4>
                            <p>We accept only online payment through <b>Instamojo</b>.</p>
                            <br />
                            <h4>Career :</h4>
                            <p>Are you a awesome thinker/coder ? Join our team <b>info@sysmocart.com</b></p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

function mapStateToProps(store){
    return {}
}

export default connect(mapStateToProps)(About)
