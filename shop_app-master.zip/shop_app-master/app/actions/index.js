import * as types from './types';
import request from 'superagent';
import { REHYDRATE } from 'redux-persist/constants';


export function getCartData() {
	return function (dispatch) {
    	return dispatch({type: types.CART_DATA})
	}
}

export function sendChangePasswordOtp(values, callback) {
	return function (dispatch) {
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/forget_password')
	      .send(values)
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			 	callback && callback({ isSuccess: true, error: null, mobile: res.body.mobile })
		  	} else {
		  		callback && callback({ isSuccess: false, error: res.body.message })
		  	}
		});
	}
}

export function handleChangePassword(values, callback) {
	return function (dispatch) {
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/change_password')
	      .send(values)
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			 	callback && callback({ isSuccess: true, error: null })
		  	} else {
		  		callback && callback({ isSuccess: false, error: (res.body.message ? res.body.message : res.body.error) })
		  	}
		});
	}
}


export function handlePayment(products, callback) {
	// https://api.sysmocart.com:443/v1/payment
	const token = localStorage.token;
	return function (dispatch) {
	    return request
	      .post('https://api.sysmocart.com:443/v1/payment')
	      .send({products: products})
	      .set('accept', 'json')
	      .set('Authorization', token)
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	callback && callback(res.body)
		});
	}
}

export function fetchProducts(catagory, page, loader, isNew) {
	return function (dispatch) {
		dispatch({type: types.CART_DATA, loader: loader });
	    return request
	      .get('https://api.sysmocart.com:443/v1/products')
	      .query({ page: page, catagory: catagory })
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.body.status == true){
			 	dispatch({type: types.CART_DATA_SUCCESS, data: res.body, isNew: isNew})
		  	} else {
		  		dispatch({type: types.CART_DATA_FAILED})
		  	}
		});
	}
}

export function fetchFilters() {
	return function (dispatch) {
		dispatch({type: types.FETCH_FILTERS });
	    return request
	      .get('https://api.sysmocart.com:443/v1/products/filters')
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.body.status == true){
			 	dispatch({type: types.FETCH_FILTERS_SUCCESS, data: res.body})
		  	} else {
		  		dispatch({type: types.FETCH_FILTERS_SUCCESS, data: {} })
		  	}
		});
	}
}

export function search(q) {
	return function (dispatch) {
		dispatch({type: types.SEARCH });
	    return request
	      .get('https://api.sysmocart.com:443/v1/products/search')
	      .query({ q: q })
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	dispatch({type: types.SEARCH_SUCCESS, data: res.body})
		});
	}
}


export function fetchSingleProducts(productId, callback) {
	return function (dispatch) {
		dispatch({type: types.CART_DATA, loader: true});
	    return request
	      .get(`https://api.sysmocart.com:443/v1/products/${productId}`)
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.body.status == true){
			 	dispatch({type: types.CART_DATA_SUCCESS, data: res.body, isNew: true})

			 	callback && callback();
		  	} else {
		  		dispatch({type: types.CART_DATA_FAILED})
		  	}
		});
	}
}


export function validateProducts(products, callback) {

	const validateProd= JSON.stringify(products.map(Number));
	return function (dispatch) {
		dispatch({type: types.CART_VALIDATE});
	    return request
	      .post('https://api.sysmocart.com:443/v1/products/validate')
	      .send({products: validateProd})
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.body.status == true){
			 		dispatch({type: types.CART_VALIDATE_SUCCESS, data: res.body})
			 		callback && callback()
		  	} else {
		  		dispatch({type: types.CART_VALIDATE_FAILED})
		  		callback && callback()
		  	}
		});
	}
}



export function emptyCartData() {
	return function (dispatch) {
    	return dispatch({type: types.CART_EMPTY})
	}
}


export function handleAddCart(cartProducts) {
	return function (dispatch) {
    	return dispatch({type: types.CART_COUNT, cartProducts: cartProducts})
	}
}

export function changeCartQuantity(newCount, cartId) {
	return function (dispatch) {
    	return dispatch({type: types.CART_QUANTITY_CHANGE, newCount: newCount, cartId: cartId})
	}
}

export function handleCartRemove(cartId, qty) {
	// console.log(count, cartProducts)
	return function (dispatch) {
    	return dispatch({type: types.CART_REMOVE, cartId: cartId, qty: qty})
	}
}


export function fetchOrders() {
	const token = localStorage.token;
	return function (dispatch) {
		dispatch({type: types.FETCH_ORDERS});
	    return request
	      .post('https://api.sysmocart.com:443/v1/orders/user')
	      .set('Authorization', token)
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			 dispatch({type: types.FETCH_ORDERS_SUCCESS, data: res.body})
		  	} else {
		  		dispatch({type: types.FETCH_ORDERS_FAILED})
		  	}
		});
	}
}


export function fetchSingleOrders(order_id) {
	const token = localStorage.token;
	return function (dispatch) {
		dispatch({type: types.FETCH_ORDERS});
	    return request
	      .post('https://api.sysmocart.com:443/v1/orders/single')
	      .send({order_id: order_id})
	      .set('Authorization', token)
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			 dispatch({type: types.FETCH_ORDERS_SUCCESS, data: res.body})
		  	} else {
		  		dispatch({type: types.FETCH_ORDERS_FAILED})
		  	}
		});
	}
}


export function userLogin(values, callback) {
	return function (dispatch) {
		dispatch({type: types.USER_LOGIN});
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/login')
	      .send({ username: values.username, password: values.password })
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			 dispatch({type: types.USER_LOGIN_SUCCESS, data: res.body})
			 callback && callback({ isSuccess: true, error: null })
		  	} else {
			 dispatch({type: types.USER_LOGIN_FAILED, data: res.body})
			 callback && callback({ isSuccess: false, error: res.body})
		  	}
		});
	}
}

export function getuserData() {
	const token = localStorage.token;
	return function (dispatch) {
	    return request
	      .get('https://api.sysmocart.com:443/v1/auth/getuserdetails')
	      .set('Authorization', token)
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			 dispatch({type: types.USER_LOGIN_SUCCESS, data: res.body})
		  	} else {
			 dispatch({type: types.USER_LOGIN_FAILED, data: res.body})
		  	}
		});
	}
}

export function sendOTP() {
	const token = localStorage.token;
	return function (dispatch) {
		dispatch({type: types.SEND_OTP});
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/request_otp')
	      .set('accept', 'json')
	      .set('Authorization', token)
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			 dispatch({type: types.SEND_OTP_SUCCESS})
		  	} else {
			 dispatch({type: types.SEND_OTP_FAILED})
		  	}
		});
	}
}

export function mobileVerifyOTP(otp, callback) {
	const token = localStorage.token;
	return function (dispatch) {
		dispatch({type: types.VERIFY_MOBILE_OTP});
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/verify_mobile')
	      .send({ otp: otp })
	      .set('accept', 'json')
	      .set('Authorization', token)
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
		  		if(res.body.status){
			 		dispatch({type: types.VERIFY_MOBILE_OTP_SUCCESS})
			 		callback && callback({ isOTPVerified: true })
		  		} else {
		  			dispatch({type: types.VERIFY_MOBILE_OTP_FAILED})
		  			callback && callback({ isOTPVerified: false })
		  		}
		  	} else {
			 dispatch({type: types.VERIFY_MOBILE_OTP_FAILED})
			 callback && callback({ isOTPVerified: false })
		  	}
		});
	}
}

export function userRegisteration(values, callback) {
	return function (dispatch) {
		dispatch({type: types.USER_REGISTER});
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/register')
	      .send({ mobile: values.mobile, password: values.password, email: values.email })
	      .set('accept', 'json')
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			    dispatch({type: types.USER_REGISTER_SUCCESS, data: res.body})
			    callback && callback({ isSuccess: true, error: null})
		  	} else {
			 	dispatch({type: types.USER_REGISTER_FAILED, data: res.body})
			 	callback && callback({ isSuccess: false, error: res.body})
		  	}
		});
	}
}


export function handleLogout() {
	return function (dispatch) {
		 dispatch({type: types.USER_LOGOUT})
	}
}


export function getUserAddress() {
	const token = localStorage.token;
	return function (dispatch) {
		dispatch({type: types.FETCH_USER_ADDRESS_LOADING});
	    return request
	      .get('https://api.sysmocart.com:443/v1/auth/address')
	      .set('accept', 'json')
	      .set('Authorization', token)
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
			    dispatch({type: types.FETCH_USER_ADDRESS, data: res.body.data})
		  	} else {
			 	dispatch({type: types.USER_LOGOUT})
		  	}
		});
	}
}

export function updateUserAddress(values, current, callback) {
	const token = localStorage.token;
	return function (dispatch) {
		// dispatch({type: types.USER_REGISTER});
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/address_update')
	      .set('accept', 'json')
	      .set('Authorization', token)
	      .send({ ...values, address_id: current})
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
		  		callback && callback()
			    // dispatch({type: types.UPDATE_ADDRESS, data: res.body.data})
		  	} else {
			 	alert("Something went wrong..")
		  	}
		});
	}
}


export function addUserAddress(values, callback) {
	const token = localStorage.token;
	return function (dispatch) {
		// dispatch({type: types.USER_REGISTER});
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/address')
	      .set('accept', 'json')
	      .set('Authorization', token)
	      .send(values)
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
		  		callback && callback()
			    // dispatch({type: types.UPDATE_ADDRESS, data: res.body.data})
		  	} else {
			 	alert("Something went wrong..")
		  	}
		});
	}
}


export function deleteUserAddress(address_id, callback) {
	const token = localStorage.token;
	return function (dispatch) {
		// dispatch({type: types.USER_REGISTER});
	    return request
	      .post('https://api.sysmocart.com:443/v1/auth/address_delete')
	      .set('accept', 'json')
	      .set('Authorization', token)
	      .send({address_id: address_id})
	      .set('Content-Type', 'application/x-www-form-urlencoded')
		  .end(function(err, res) {
		  	if(res.status == 200){
		  		callback && callback()
			    // dispatch({type: types.UPDATE_ADDRESS, data: res.body.data})
		  	} else {
			 	alert("Something went wrong..")
		  	}
		});
	}
}




