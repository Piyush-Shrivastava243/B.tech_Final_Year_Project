import { routerReducer as routing } from 'react-router-redux';
import { combineReducers } from 'redux';
import * as types from '../actions/types';
import { REHYDRATE } from 'redux-persist/constants';
import { reducer as formReducer } from 'redux-form'
import _ from 'lodash';


const initialState = {
    cartCount: 0,
    cartProducts: [],
}

const initialProducts = {
    isOrderFetching: false,
    isProductLoading: false,
    Products: { products: [] },
    userAddress: [],
    selectedAddress: null,
    addressFetching: false,
    validatingCart: false,
    liveCartItems: [],
    filters: {},
    filterLoading: false,
    search: [],
    searchLoading: false
}

const userLoginState = {
    isLoggedIn: false,
    loginError: null,
    RegisterError: null,
    loginUser: null,
    isLoginLoading: false,
    isRegistering: false,
    isOTPSending: false,
    OTPSent: false,
    isMobileVerifying: false,
    isVerified: false,
    isPasswordChanges: false
}


const cart = (state = initialState, action) => {
    switch (action.type) {
        case types.CART_COUNT:
            return {
                ...state,
                cartCount: _.sumBy(state.cartProducts, function(o) { return o.qty; }),
                cartProducts: action.cartProducts
            }
         case types.CART_EMPTY:
            return {
                ...state,
                cartCount: 0,
                cartProducts: []
            }
        case types.CART_REMOVE:
            _.remove(state.cartProducts, {cartId: action.cartId})
            return {
                ...state,
                cartCount: (state.cartCount - action.qty)
            }
        case types.CART_QUANTITY_CHANGE: 
            const findTarget = _.find(state.cartProducts, function(item) { return item.cartId == action.cartId })
            const newCartCount = (findTarget.qty < action.newCount ? (state.cartCount - (findTarget.qty - action.newCount)) : (state.cartCount + (action.newCount - findTarget.qty)));
            findTarget.qty = action.newCount;
            return {
                ...state,
                cartCount: newCartCount
            }
        case REHYDRATE:
          var incoming = action.payload.myReducer
          if (incoming) return {...state, ...incoming, specialKey: processSpecial(incoming.specialKey)}
          return state
        default:
            return state;
    }
};

const getProducts = (state = initialProducts, action) => {
    switch (action.type) {
        case types.CART_DATA:
            return {
                ...state,
                isProductLoading: action.loader ? action.loader :  false
            }
        case types.CART_DATA_SUCCESS:
            if(action.isNew) {
                state.Products.products = [];
            }
            let newObj = {...state.Products}
            newObj.products = [...state.Products.products, ...action.data.products]
            return {
                ...state,
                isProductLoading: false,
                Products: newObj
            }
        case types.CART_DATA_FAILED:
            return {
                ...state,
                isProductLoading: false
            }

        case types.CART_VALIDATE:
            return {
                ...state,
                validatingCart: true
            }
        case types.CART_VALIDATE_SUCCESS:
            return {
                ...state,
                validatingCart: false,
                liveCartItems: action.data
            }
        case types.CART_VALIDATE_FAILED:
            return {
                ...state,
                validatingCart: false
            }


        case types.FETCH_ORDERS:
            return {
                ...state,
                isOrderFetching: true
            }
        case types.FETCH_ORDERS_SUCCESS:
            return {
                ...state,
                Orders: action.data,
                isOrderFetching: false
            }


        case types.FETCH_FILTERS:
            return {
                ...state,
                filterLoading: true
            }
        case types.FETCH_FILTERS_SUCCESS:
            return {
                ...state,
                filters: action.data,
                filterLoading: false
            }

        case types.SEARCH:
            return {
                ...state,
                searchLoading: true
            }
        case types.SEARCH_SUCCESS:
            return {
                ...state,
                search: action.data,
                searchLoading: false
            }

        case types.CLEAR_SEARCH:
            return {
                ...state,
                search: [],
            }


        case types.FETCH_ORDERS_FAILED:
            return {
                ...state,
                isOrderFetching: false
            }
        case types.FETCH_USER_ADDRESS_LOADING:
            return {
                ...state,
                addressFetching: true
            }
        case types.FETCH_USER_ADDRESS:
            return {
                ...state,
                userAddress: action.data,
                selectedAddress: action.data.length ? action.data[0].id : null,
                addressFetching: false
            }
        case types.SELECTED_ADDRESS:
            return {
                ...state,
                selectedAddress: action.selectedAddress
            }
        default:
            return state;
    }
};

const userLogin = (state = userLoginState, action) => {
    switch (action.type) {
        case types.USER_LOGIN:
            return {
                ...state,
                isLoginLoading: true
            }
        
         case types.USER_LOGIN_SUCCESS:
            localStorage.setItem("token", action.data.data.token);
            return {
                ...state,
                loginUser: action.data,
                isLoggedIn: true,
                isLoginLoading: false
            }
         case types.USER_LOGIN_FAILED:
            return {
                ...state,
                loginUser: null,
                isLoggedIn: false,
                loginError: action.data,
                isLoginLoading: false
            }
         case types.USER_REGISTER:
            return {
                ...state,
                isRegistering: true
            }
         case types.USER_REGISTER_SUCCESS:
            localStorage.setItem("token", action.data.data.token);
            return {
                ...state,
                loginUser: action.data,
                isLoggedIn: true,
                isRegistering: false
            }
         case types.USER_REGISTER_FAILED:
            return {
                ...state,
                loginUser: null,
                isLoggedIn: false,
                isRegistering: false,
                RegisterError: action.data
            }
         case types.USER_LOGOUT:
            localStorage.removeItem("token");
            return {
                ...state,
                loginUser: null,
                isLoggedIn: false
            }
         case types.SEND_OTP:
            return {
                ...state,
                isOTPSending: true,
                OTPSent: true
            }
         case types.SEND_OTP_SUCCESS:
            return {
                ...state,
                isOTPSending: false,
                OTPSent: true
            }
         case types.SEND_OTP_FAILED:
            return {
                ...state,
                isOTPSending: false,
                OTPSent: false
            }
         case types.VERIFY_MOBILE_OTP:
            return {
                ...state,
                isMobileVerifying: true,
                isVerified: false
            }
         case types.VERIFY_MOBILE_OTP_SUCCESS:
            return {
                ...state,
                isMobileVerifying: false,
                isVerified: true
            }
         case types.VERIFY_MOBILE_OTP_FAILED:
            return {
                ...state,
                isMobileVerifying: false,
                isVerified: false
            }
         case types.FORGET_PASSWORD_SUCCESS:
            return {
                ...state,
                isPasswordChanges: true
            }
        case types.FORGET_PASSWORD_OTP:
            return {
                ...state,
                isOtpSent: true
            }
        default:
            return state;
    }
};




const rootReducer = combineReducers({
    cart,
    getProducts,
    userLogin,
    routing,
    form: formReducer
});

export default rootReducer;
