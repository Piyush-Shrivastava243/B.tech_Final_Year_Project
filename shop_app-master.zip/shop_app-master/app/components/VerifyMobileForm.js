import React from 'react'
import { Field, reduxForm } from 'redux-form'
import TextField from 'material-ui/TextField'
import { connect } from 'react-redux'
import CircularProgress from 'material-ui/CircularProgress';

import {
  Step,
  Stepper,
  StepLabel,
} from 'material-ui/Stepper';
import RaisedButton from 'material-ui/RaisedButton';
import FlatButton from 'material-ui/FlatButton';

const required = value => value ? undefined : 'Required'

const minValue = value =>  value && value.length < 6 ? 'Must be at least 6' : undefined

const otp = value =>
  value && !/^\d{6}$/i.test(value) ?
  'Please enter the OTP sent via SMS' : undefined

const mobile = value =>
  value && !/^\d{10}$/i.test(value) ?
  'Please enter the OTP sent via SMS' : undefined

const renderTextField = ({ input, label, meta: { touched, error }, ...custom }) => (
  <TextField autoComplete="off" hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)

const getStepContent = (stepIndex, mobile, isOTPSending, OTPSent)=> {
    switch (stepIndex) {
      case 0:
        return (
			<span>
				Your Primary Mobile Number is <b>{mobile}</b>
			</span>
        )
      case 1:
        return(
        	<form>
        	  {isOTPSending ? <CircularProgress size={40} thickness={7} /> :
        	  <div>
			      <span>OTP is sent successfully to your primary number <b>{mobile}</b></span>
			      <div>
			        <Field name="otp" validate={[ required, otp ]} component={renderTextField} label="Enter OTP"/>
			      </div>
			      </div> }
		    </form>
        )

      default:
        return 'Something Went Wrong!';
    }
  }

const VerifyMobileForm = props => {
  const { valid, isLoginLoading, isMobileForm } = props;
  const contentStyle = {margin: '0 16px'};
  return (
  	<div style={{width: '100%', maxWidth: 700, margin: 'auto'}}>
        <Stepper activeStep={props.stepIndex}>
          <Step>
          	<StepLabel>Send OTP</StepLabel>
          </Step>
          <Step>
          	<StepLabel>Enter OTP</StepLabel>
          </Step>
        </Stepper>
        <div style={contentStyle}>
          <div>{getStepContent(props.stepIndex, props.mobile, props.isOTPSending, props.TPSent)}</div>
          <div style={{marginTop: 12}}>
            <FlatButton
              label="Back"
              disabled={props.stepIndex === 0}
              onClick={props.handlePrev}
              style={{marginRight: 12}}
            />
            <RaisedButton
              label={props.stepIndex === 0 ? (props.counter > 0 ? 'Send OTP '+props.counter : 'SEND OTP') : (props.isMobileVerifying ? <CircularProgress size={25} thickness={5} /> : 'VERIFY OTP')}
              primary={true}
              disabled={props.stepIndex === 0 && props.counter > 0 || props.stepIndex === 1 && props.isOTPSending || props.stepIndex === 1 && !valid || props.stepIndex === 1 && props.isMobileVerifying}
              onClick={props.handleNext}
            />
          </div>
        </div>
    </div>
  )
}

export default reduxForm({
  form: 'VerifyMobileForm',  // a unique identifier for this form
})(VerifyMobileForm)