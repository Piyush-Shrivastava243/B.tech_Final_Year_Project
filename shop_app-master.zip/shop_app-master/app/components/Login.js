import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
// import AlertContainer from 'react-alert';
import queryString from 'query-string';
import LoginForm from './LoginForm';
import { reset } from 'redux-form';
import Snackbar from 'material-ui/Snackbar';
import { Link } from 'react-router-dom';
import { isMobile } from '../Helper/Common';


import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {cyan500, cyan700,  pinkA200,  grey100, grey300, grey400, grey500,  white, darkBlack, fullBlack,} from 'material-ui/styles/colors';

const muiTheme = getMuiTheme({
  palette: {
    textColor: darkBlack,
    alternateTextColor: white
  },
  appBar: {
    height: 50,
  },
});


class Login extends React.Component {
    state = {
        username: '',
        password: '',
        open: false,
        message: ''
    }
    componentDidMount() {
        this.props.dispatch(reset('LoginForm'));
        if(this.props.isLoggedIn){
            this.props.history.push("/products");
        }
    }

    componentWillReceiveProps(nextProps){
        const parsed = queryString.parse(this.props.location.search);
        if(nextProps.isLoggedIn && !this.props.isLoggedIn){
            this.props.history.push(parsed.next ? parsed.next : '/products');
        }
        
    }

    handleLogin = (values)=> {
        this.props.dispatch(actions.userLogin(values, (res) => {
            if (!res.isSuccess) {
                this.setState({ open: true, message: res.error.error});
                this.props.dispatch(reset('LoginForm'));
            } 
        }))
    }

    render() {
        const { isLoginLoading } = this.props;
        return(
            <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
                <div className="login-main">
                    <div className="login-box">
                        <MuiThemeProvider muiTheme={muiTheme}>
                            <div>
                                <LoginForm isLoginLoading={isLoginLoading} onSubmit={this.handleLogin} />
                                <div className="login-link-container">
                                    <Link to="/password" className="login-link">Forget?</Link>
                                    <div className="login-right-links">
                                        <Link to="/register" className="login-create-account-link login-link">Create Account</Link>
                                    </div>
                                </div>
                                <Snackbar
                                  open={this.state.open}
                                  message={this.state.message}
                                  autoHideDuration={3000}
                                  onRequestClose={() => this.setState({ open: false })}
                                />
                            </div>
                        </MuiThemeProvider>
                        <div className="clearfix"></div>
                    </div>
                    
                </div>
            </div>
        );
    }
}

function mapStateToProps(store){
    return {
        userData: store.userLogin.loginUser,
        isLoggedIn: store.userLogin.isLoggedIn,
        loginError: store.userLogin.loginError,
        isLoginLoading: store.userLogin.isLoginLoading
    }
}

export default connect(mapStateToProps)(Login)
