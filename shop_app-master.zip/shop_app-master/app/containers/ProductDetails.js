import React from 'react';
import { Link } from 'react-router-dom';
import Routes from '../routes';
import { connect } from 'react-redux';
import * as actions from '../actions';
import { browserHistory } from 'react-router-dom';
import AlertContainer from 'react-alert';
import _ from 'lodash';
import FaCartPlus from 'react-icons/lib/fa/cart-plus';
import FaClose from 'react-icons/lib/fa/close';
import ArrowRight from 'react-icons/lib/fa/arrow-right';
import { PulseLoader } from 'react-spinners';
import { isMobile } from '../Helper/Common';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';
import Countdown from '../Helper/Countdown'
import { Helmet } from "react-helmet";
import LazyLoad from 'react-lazy-load';
import { Image } from 'cloudinary-react';


import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";



class ProductDetails extends React.Component {
  state = {
    isAdded: false,
    size: null,
    showError: false,
  }
  componentDidMount() {
    const productId = this.props.match.params.productId;
    this.props.dispatch(actions.fetchSingleProducts(productId));
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.match.params.productId != this.props.match.params.productId) {
      this.props.dispatch(actions.fetchSingleProducts(nextProps.match.params.productId));
    }
  }

  alertOptions = {
    offset: 14,
    position: 'top left',
    theme: 'dark',
    time: 5000,
    transition: 'scale'
  }

  handleRadioSize = (size) => {
    this.setState({size: size, isAdded: false})
  }


  handleAddCart = ()=> {
    console.log(this.state)
    if(this.state.size) {
      if(this.state.isAdded){
        this.props.history.push("/checkout/cart");
      } else {
        const cartProducts = this.props.cartProducts ? this.props.cartProducts : [];
        // const isExist = _.find(cartProducts, function(o) { return o.productId == productId; });
        const findProduct = this.props.Products[0];
        let pObject;
        const cartId = (findProduct.id+'#'+ this.state.size);
        const isCartExist = _.find(cartProducts, function(o) { return o.cartId == cartId; });

        if(isCartExist == undefined || isCartExist == null){
          pObject = {
            productId: findProduct.id,
            defaultImage: findProduct.default_image,
            cartId: cartId,
            qty: 1,
            Product: findProduct,
            size: this.state.size
          }
          cartProducts.push(pObject)

        } else {
            // for(let i=0; i<cartProducts.length; i++){
            //   if(cartProducts[i].cartId == cartId){
            //     cartProducts[i].qty = cartProducts[i].qty + 1;
            //   }
            // }
        }

        this.props.dispatch(actions.handleAddCart(cartProducts));
        this.msg.show('Added Product To Cart', {
          time: 2000,
          type: 'success'
        })
      }
      this.setState({isAdded: true});
     } else {

      if(!this.state.size) {
        this.setState({showError: true});
        setTimeout(() => {
          this.setState({showError: false});
        }, 2000)
      }
    }

  }
  goToBag = ()=> {
    window.location.href = '/checkout/cart';
  }

  render() {
    const { cartCount, Products, isProductLoading } = this.props;
    const productId = this.props.match.params.productId;
    const productDetails = Products && Products[0];

    console.log(Products)

    const discountPercent = productDetails && ((productDetails.mrp-productDetails.discounted)/productDetails.mrp*100).toFixed(0);


    const sizes = productDetails && JSON.parse(productDetails.sizes);
    const images = productDetails && JSON.parse(productDetails.images);

    let showRemaining = null;
    if(this.state.size){
      const countSize  = _.find(sizes, (o)=> { return o.label == this.state.size; });
      showRemaining = countSize.count;
    }

    const tooltip = (size)=> (
      <Tooltip id="tooltip">
        <strong>{size}</strong>
      </Tooltip>
    );


    let hasAnError = false;
    if(this.state.showError) {
      hasAnError = true;
    }

    const OPTIONS = { endDate: '02/22/2018 11:59 PM'}


    const settings = {
      customPaging: function(i) {
        return (
          <a>
            <Image cloudName="sysmocart" publicId={images && images[i]} height="50" quality="50" format="jpeg" crop="scale"/>
          </a>
        );
      },
      dots: true,
      dotsClass: "product-details-slider",
      infinite: true,
      speed: 500,
      arrows: false,
      lazyLoad: true,
      slidesToShow: 1,
      slidesToScroll: 1
    };

    const mobileSettings = {
      dots: true,
      infinite: true,
      lazyLoad: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1
    };

    return(
      <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
      <Helmet>
          <meta charSet="utf-8" />
          <title>{isProductLoading ? 'Loading...' : `Buy ${productDetails && productDetails.name} | Sysmocart`}</title>
          <meta name="description" content={`Buy ${productDetails && productDetails.name}`} />
          <meta name="keywords" content={`${productDetails && productDetails.name} | Sysmocart`} />
      </Helmet>
        <div className="women_main">
          <div className="row single" style={isMobile() ? {marginRight: 0, marginLeft: 0 } : null}>
            <div className="col-md-12">
              {isProductLoading ?
              <div style={isProductLoading ? {textAlign: '-webkit-center', minHeight: '600px'} : null}>
                <PulseLoader
                  color={'#56bfea'} 
                  loading={isProductLoading} 
                />
              </div> :
              <div>
                <div className="single_left">
                  <div style={isMobile() ? null : {marginLeft: '30px'}} className={isMobile()  ? null : 'col-md-4'}>
                  { isMobile() ?

                    <LazyLoad height={500} offsetVertical={300}>
                      <Slider {...mobileSettings}>
                        {images && images.map((image, key) => {
                          return (
                            <div key={key}>
                              <Image cloudName="sysmocart" publicId={image} width="345" quality="80" format="jpeg" crop="scale"/>
                            </div>
                          )
                        })}
                      </Slider>
                    </LazyLoad> :
                    
                    <LazyLoad height={464} offsetVertical={300}>
                      <Slider {...settings}>
                        {images && images.map((image, key) => {
                          return (
                            <div key={key}>
                              <Image cloudName="sysmocart" publicId={image} width="350" quality="70" format="jpeg" crop="scale"/>
                            </div>
                          )
                        })}
                      </Slider>
                    </LazyLoad> 
                  }

                    <p style={{paddingTop: '10px', fontSize: '10px'}}>Color may vary from the picture | Sold By: <b>{productDetails && productDetails.soldby}</b></p>
                    <div className="clearfix"></div>       
                  </div>
                  <div className={isMobile() ? null : 'desc1 span_3_of_2'}>
                    <h3>{productDetails && productDetails.name}</h3>
                    { discountPercent > 0 && <h2 className="pdp-discount-container"><s>₹{productDetails && productDetails.mrp}</s><span className="pdp-discount">({discountPercent}% OFF)</span></h2>}
                    <p>₹{productDetails && productDetails.discounted}</p>
                    {/*<span className="count-down-text">Extra ₹40 discount ends in less than  <Countdown options={OPTIONS} /></span>*/}
                    <div className="det_nav1">
                      <h4>Select a size {showRemaining && showRemaining < 3 && <span style={{marginLeft: '10px', fontSize: '10px', color: 'red'}}>ONLY {showRemaining} ITEM LEFT</span>}</h4>
                      { productDetails && productDetails.in_stock == 0 ?
                        <span style={{color: '#f16565'}}>THIS PRODUCT IS CURRENTLY SOLD OUT</span> :
                        <div className="sky-form col col-4 select-sizes">
                        <ul style={{paddingTop: '5px'}} className={this.state.showError ? 'shake-btn' : ''}>
                        { sizes && sizes.map((data, index) => {
                          if(data.count > 0){
                            if(!isMobile()) {
                              return(
                                <OverlayTrigger key={index} placement="top" overlay={tooltip(data.size)}>
                                  <li className={this.state.size == data.label ? 'selected' : null} onClick={()=> this.handleRadioSize(data.label)}>
                                    <span>{data.label}</span>
                                  </li>
                                </OverlayTrigger>
                              )
                            } else {
                              return (
                                <li key={index} className={this.state.size == data.label ? 'selected' : null} onClick={()=> this.handleRadioSize(data.label)}>
                                  <span>{data.label}</span>
                                </li>
                              )
                            }
                          }
                        })}
                        </ul>
                        {this.state.showError && <span style={{color: 'red'}}><small><b>Please select a size</b></small></span>}
                        </div>
                      }
                    </div>

                    <div className="det_nav1">
                      <h4>Product Details</h4>
                      <span style={{fontSize: '0.8em'}}>{productDetails && productDetails.description}</span>
                    </div>


                    <AlertContainer ref={a => this.msg = a} {...this.alertOptions} />
                    { productDetails && productDetails.in_stock == 1 &&
                      <div className="btn_form">
                          <button onClick={ this.handleAddCart } className="add-bag-btn" href="/checkout/cart">{ this.state.isAdded ? <ArrowRight size={20} /> : <FaCartPlus size={20} />} {this.state.isAdded ? 'GO TO CART' : 'ADD TO BAG'}</button>
                          { hasAnError &&
                          <h6 style={{marginTop: '5px', color: 'red'}}>Required Above Fields</h6> }
                      </div>
                    }


                  </div>
                  <div className="clearfix"></div>
                </div>
                <div className="single-bottom1">
                  <h6>Details</h6>
                  <p className="prod-desc">{productDetails && productDetails.description}</p>
                </div>
              </div> }
            </div> 
          <div className="clearfix"></div>     
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(store){
  return {
    cartCount: store.cart.cartCount,
    cartProducts: store.cart.cartProducts,
    Products: store.getProducts.Products.products,
    isProductLoading: store.getProducts.isProductLoading
  }
}

export default connect(mapStateToProps)(ProductDetails)

