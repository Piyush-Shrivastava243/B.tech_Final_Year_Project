import MobileDetect from 'mobile-detect';
import _ from 'lodash';


export function isMobile() {
    const md = new MobileDetect(window.navigator.userAgent);
    const isMobile = md.mobile() ? true : false;
    return isMobile;
}


export function  validateProducts(data, liveCartItems, cart) {

  const liveData =  _.find(liveCartItems.products, { 'id': data.productId });


	const quantity = liveData && JSON.parse(liveData.sizes);
  const availableItems = _.find(quantity, { 'label': data.size });
  const inStock = availableItems && liveData.in_stock == 1 && liveData.isActive == 1 && availableItems.count > 0 ? true : false;
  const isValidQuantity = availableItems && parseInt(availableItems.count) >= parseInt(data.qty) ? false : true;

  return {
  	inStock: inStock,
  	isValidQuantity: !isValidQuantity,
  	id: data.productId
  }

}


export function validateCart(cart, live) {
		let isValidCart = true;

    for(var i=0; i<cart.length; i++) {
    	const validateCartItems = validateProducts(cart[i], live, cart);
    	if(!validateCartItems.inStock || !validateCartItems.isValidQuantity) {
    		isValidCart = false
    	}
    }

    return isValidCart;
}





