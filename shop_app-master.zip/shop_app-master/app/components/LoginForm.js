import React from 'react'
import { Field, reduxForm } from 'redux-form'
import TextField from 'material-ui/TextField'
import { connect } from 'react-redux'
import CircularProgress from 'material-ui/CircularProgress';

const required = value => value ? undefined : 'Required'

const minValue = value =>  value && value.length < 6 ? 'Must be at least 6' : undefined

const EmailOrMobile = (value) => {
    const phoneMobile = /^\d{10}$/i.test(value);
    const validEmail = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value);
    
    if (!phoneMobile && validEmail) {
      return undefined;
    }

    if (!validEmail && phoneMobile) {
      return undefined;
    }

    if(!phoneMobile && !validEmail) {
      return 'Incorrect Email Or Mobile';
    }
}
  

const mobile = value =>
  value && !/^\d{10}$/i.test(value) ?
  'Invalid Email or Mobile' : undefined


const renderTextField = ({ input, label, meta: { touched, error }, ...custom }) => (
  <TextField autoComplete="off" hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)

const LoginForm = props => {
  const { handleSubmit, pristine, reset, valid, submitting, isLoginLoading } = props;
  return (
    <form onSubmit={handleSubmit}>
      <div>
        <Field name="username" validate={[ required, EmailOrMobile ]} component={renderTextField} label="Email or Mobile"/>
      </div>
      <div>
        <Field validate={[ required, minValue ]}  name="password" type="password" component={renderTextField} label="Password"/>
      </div>
      <div>
        <button type="submit" style={isLoginLoading ?{padding: '9px'} : {}} className="login-login-button" disabled={pristine || submitting || !valid}>{isLoginLoading ? <CircularProgress size={25} thickness={5} /> : 'SIGN IN' }</button>
      </div>
    </form>
  )
}

export default reduxForm({
  form: 'LoginForm',  // a unique identifier for this form
})(LoginForm)