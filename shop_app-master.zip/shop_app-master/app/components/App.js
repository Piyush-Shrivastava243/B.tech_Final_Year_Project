import React from 'react';
import { Link } from 'react-router-dom';
import Routes from '../routes';
import { connect } from 'react-redux';
import FaUser from 'react-icons/lib/fa/user';
import FaShoppingBag from 'react-icons/lib/fa/shopping-bag';
import * as actions from '../actions';
import AlertContainer from 'react-alert';

import MenuItem from 'material-ui/MenuItem';
import RemoveRedEye from 'material-ui/svg-icons/image/remove-red-eye';
import PersonAdd from 'material-ui/svg-icons/social/person-add';
import Person from 'material-ui/svg-icons/social/person';
import SettingsPower from 'material-ui/svg-icons/action/settings-power';
import AccountCircle from 'material-ui/svg-icons/action/account-circle';
import Divider from 'material-ui/Divider';
import AppBar from 'material-ui/AppBar';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {white, darkBlack} from 'material-ui/styles/colors';
import { Button, Modal } from 'react-bootstrap';

import NavigationMenu from 'material-ui/svg-icons/navigation/menu';
import ActionShoppingBasket from 'material-ui/svg-icons/action/shopping-basket';
import FlatButton from 'material-ui/FlatButton';
import IconButton from 'material-ui/IconButton';
import Drawer from 'material-ui/Drawer';
import Menu from 'material-ui/Menu';


import Autosuggest from 'react-autosuggest';
import AutosuggestHighlightMatch from "autosuggest-highlight/umd/match";
import AutosuggestHighlightParse from "autosuggest-highlight/umd/parse";

import Badge from 'material-ui/Badge';
import NotificationsIcon from 'material-ui/svg-icons/social/notifications';
import { isMobile } from '../Helper/Common'

const muiTheme = getMuiTheme({
  palette: {
    textColor: darkBlack,
    alternateTextColor: white
  }
});


const people = [
  {
    first: 'Charlie',
    last: 'Brown',
    twitter: 'dancounsell'
  },
  {
    first: 'Charlotte',
    last: 'White',
    twitter: 'mtnmissy'
  },
  {
    first: 'Chloe',
    last: 'Jones',
    twitter: 'ladylexy'
  },
  {
    first: 'Cooper',
    last: 'King',
    twitter: 'steveodom'
  }
];


function getSuggestionValue(suggestion) {
  return suggestion.name;
}

function renderSuggestion(suggestion, { query }) {
  const suggestionText = suggestion.name;
  const matches = AutosuggestHighlightMatch(suggestionText, query);
  const parts = AutosuggestHighlightParse(suggestionText, matches);

  return (
    <span className='suggestion-content' data-value={`{"id": ${suggestion.id}, "category": "${suggestion.category}"}`} style={{backgroundImage: `url(${suggestion.default_image})`, backgroundSize: 'auto 45px'}}>
      <span className="name">
        {
          parts.map((part, index) => {
            const className = part.highlight ? 'highlight' : null;

            return (
              <span className={className} key={index}>{part.text}</span>
            );
          })
        }
      </span>
    </span>
  );
}


class App extends React.Component {

    state = {
      show: false,
      message: 'Welocome to SYSMOCART',
      open: false,
      showMenu: false,
      value: ''
    };


    handleToggle = () => this.setState({open: !this.state.open});

    handleClose = () => this.setState({open: false});

    handleLogout =()=> {
        this.props.dispatch(actions.handleLogout())
    }
    
    alertOptions = {
        offset: 14,
        position: 'top left',
        theme: 'dark',
        time: 5000,
        transition: 'scale'
    }

    componentDidUpdate(prevProps) {
        if (this.props.location !== prevProps.location) {
          window.scrollTo(0, 0)
        }
      }

    componentWillReceiveProps(nextProps){
        if(!nextProps.isLoggedIn && this.props.isLoggedIn){
            this.props.history.push("/products");
            this.msg.show('Logout Successfully!', {
                time: 2000,
                type: 'error'
            })
        }
        
    }

    handleHover = () => {
        this.setState({ showMenu: true });
    }

    onMouseOut = (e) => {
        if(e.currentTarget.classList.contains('megapanel')){
            this.setState({ showMenu: true });
        } else {
            this.setState({ showMenu: false });
        }
    };


    onChange = (event, { newValue, method }) => {
      this.setState({
        value: newValue
      });
      let targData = event.currentTarget.querySelector('.suggestion-content') && event.currentTarget.querySelector('.suggestion-content').dataset.value
      if(targData) {
        targData = JSON.parse(targData)
        const tageName = newValue.replace(/\s+/g, '-').toLowerCase();
        const category  = targData.category.replace(/\s+/g, '-').toLowerCase();
        this.props.history.push(`/${category}/${targData.id}/${tageName}`);

        this.props.dispatch({type: 'CLEAR_SEARCH'})
      }
    };
    
    onSuggestionsFetchRequested = ({ value }) => {
      this.props.dispatch(actions.search(value))
    };

    onSuggestionsClearRequested =()=> {
      console.log("Cleared")
    }


    render() {
        const { cartCount, userData, isLoggedIn, search, searchLoading } = this.props;
        const nextPath = this.props.location.pathname;

        const { value } = this.state;
        const inputProps = {
          placeholder: "Search for products",
          value,
          onChange: this.onChange
        };

        return(
            <div>
            
               { isMobile() ?
                <MuiThemeProvider muiTheme={muiTheme}>
                    <div>
                        <AppBar
                            style={{ backgroundColor: '#ffffff', zIndex: 100, position: 'fixed', top: 0 }}
                            title={<Link to="/"><img src="/static/images/mobilelogo.png" alt=""/></Link>}
                            iconElementLeft={<IconButton><NavigationMenu color="black" /></IconButton>}
                            onLeftIconButtonTouchTap={this.handleToggle}
                            iconElementRight={
                                <Badge
                                  badgeContent={cartCount}
                                  secondary={true}
                                  badgeStyle={{top: 6, right: 6}}
                                >
                                    <Link to="/checkout/cart"><ActionShoppingBasket /></Link>
                                </Badge>

                            }
                        />
                        <Drawer
                          docked={false}
                          width={'50%'}
                          open={this.state.open}
                          onRequestChange={(open) => this.setState({open})}
                        >
                            <Menu onItemTouchTap={this.handleClose}>
                                {isLoggedIn &&
                                    <MenuItem containerElement={<Link to="/my/profile" />} primaryText="Profile" /> }
                                {isLoggedIn &&
                                    <MenuItem containerElement={<Link to="/my/orders" />} primaryText="Orders" /> }
                                {isLoggedIn &&
                                    <MenuItem onClick={this.handleLogout} primaryText="Logout" /> }
                                {!isLoggedIn &&   
                                    <MenuItem containerElement={<Link to="/login" />} primaryText="Login" /> }
                                {!isLoggedIn &&
                                    <MenuItem containerElement={<Link to="/register" />} primaryText="Sign Up" /> }
                            
                            </Menu>
                        </Drawer>
                    </div>
                </MuiThemeProvider> : 
                <div className="header_bg">
                    <div className="container">
                        <div className="header">
                            <div id="mainlogo" className="logo" style={{marginTop: '25px', marginLeft: 20}}>
                                <Link to="/"><img src="/static/images/logo.png" width="250" alt=""/></Link>
                            </div>
                            <div className="header_right">
                            
                            <ul className="icon1 sub-icon1 profile_img">
                                <li>
                                    <Link to="/checkout/cart">
                                        <span><FaShoppingBag size={30} color="#9c9dab" />{ cartCount ? <span className="cart-badge">{cartCount}</span>: null }</span> 
                                    </Link>
                                </li>
                            </ul>
                            <ul className="icon1 sub-icon1 profile_img">
                                <li>
                                    <FaUser size={34} color="#9c9dab" />
                                    <ul className="sub-icon1 list">
                                        <MuiThemeProvider muiTheme={muiTheme}>
                                        {isLoggedIn ? 
                                             <div>
                                                <AppBar title={userData && userData.data.email} titleStyle={{fontSize: 10, textTransform: 'uppercase'}} iconElementLeft={<AccountCircle style={{width: 50, height: 50}} />} />
                                                <MenuItem primaryText="Orders" containerElement={<Link to='/my/orders' />} leftIcon={<RemoveRedEye />} />
                                                <MenuItem primaryText="Profile" containerElement={<Link to='/my/profile' />} leftIcon={<PersonAdd />} />
                                                <Divider />
                                                <MenuItem primaryText="Logout" onClick={this.handleLogout} leftIcon={<SettingsPower />} />
                                              </div>
                                        
                                        :
                                        <div>
                                            <AppBar title="SYSMOCART USER" titleStyle={{fontSize: 15, textTransform: 'uppercase'}} iconElementLeft={<AccountCircle style={{width: 50, height: 50}} />} />
                                            <MenuItem primaryText="LOGIN" containerElement={<Link to={'/login?next='+nextPath} />} leftIcon={<Person />} />
                                            <Divider />
                                            <MenuItem primaryText="SIGN UP" containerElement={<Link to='/register' />} leftIcon={<PersonAdd />} />
                                        </div>}
                                        </MuiThemeProvider>
                                    </ul>
                                </li>
                            </ul>
                            <div className="search">
                              <Autosuggest 
                              suggestions={search}
                              onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                              onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                              getSuggestionValue={getSuggestionValue}
                              renderSuggestion={renderSuggestion}
                              inputProps={inputProps} />
                            </div>
                           
                            <div className="clearfix"> </div>
                            </div>
                        </div>
                    </div>
                    <AlertContainer ref={a => this.msg = a} {...this.alertOptions} />
                </div> }
            	{ Routes }
                { isMobile() ? null :
                <div className="footer_top">
                   <div className="container">
                        <div className="span_of_4">
                            <div className="span1_of_4">
                                <h4>Buy Grocery</h4>
                                <ul className="f_nav">
                                    <li><Link to="/Fruits-And-Vegetables">Fruits And Vegetables</Link></li>
                                    <li><Link to="/Staples">Staples</Link></li>
                                    <li><Link to="/Snacks-&-Branded-Foods">Snacks & Branded Foods</Link></li>
                                </ul>   
                            </div>
                            <div className="span1_of_4">
                                <h4>account</h4>
                                <ul className="f_nav">
                                    { !isLoggedIn && <li><Link to="/login">login</Link></li>}
                                    { !isLoggedIn && <li><Link to="/register">create an account</Link></li>}
                                    { isLoggedIn && <li><Link to="/my/orders">orders</Link></li> }
                                    { isLoggedIn && <li><Link to="/my/profile">profile</Link></li> }
                                </ul>              
                            </div>
                            <div className="span1_of_4">
                                <h4>Company</h4>
                                <ul className="f_nav">
                                    <li><Link to="/about">About</Link></li>
                                    <li><Link to="/about">Career</Link></li>
                                </ul>           
                            </div>
                            <div className="span1_of_4">
                                <h4>Contact Us</h4>
                                <ul className="f_nav">
                                    <li className="contact-link">info@sysmocart.com</li>
                                </ul>    
                            </div>
                            <div className="clearfix"></div>
                            </div>
                            <div className="span_of_2">
                                <div className="span1_of_2">
                                    <div className="social-icons">
                                        <ul>
                                            <li><a href="#" target="_blank"></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div style={{float: 'right', marginRight: '1%'}}>
                                   <a href="#" target="_blank">
                                        <img src="/static/images/instamojo.png" width="230" title="Paymennt Secured By Instamojo" alt="Bulk SMS - MSG91" />
                                   </a>
                                </div>
                                <div style={{float: 'right', marginRight: '1%'}}>
                                   <a href="https://msg91.com/startups/?utm_source=startup-banner" target="_blank">
                                        <img src="/static/images/sms.png" width="120" height="90" title="MSG91 - SMS for Startups" alt="Bulk SMS - MSG91" />
                                   </a>
                                </div>
                                <div className="clearfix"></div>
                            </div>
                    </div>
                </div> }
                { isMobile() ? 
                    <div style={{padding: '10px 20px'}}>
                        <div style={{padding: '25px'}}>
                            <div className="span_of_4">
                                <div>
                                    <h4>account</h4>
                                    <ul className="f_nav">
                                        { !isLoggedIn && <li><Link to="/login">login</Link></li>}
                                        { !isLoggedIn && <li><Link to="/register">create an account</Link></li>}
                                        { isLoggedIn && <li><Link to="/my/orders">orders</Link></li> }
                                        { isLoggedIn && <li><Link to="/my/profile">profile</Link></li> }
                                    </ul>              
                                </div>
                                <div>
                                    <h4>Company</h4>
                                    <ul className="f_nav">
                                        <li><Link to="/about">About</Link></li>
                                        <li><Link to="/about">Career</Link></li>
                                    </ul>           
                                </div>
                                <div>
                                    <h4>Contact Us</h4>
                                    <ul className="f_nav">
                                        <li className="contact-link">info@sysmocart.com</li>
                                    </ul>    
                                </div>
                                <div className="clearfix"></div>
                            </div>
                        </div>
                    </div>
                :
                <div className="footer">
                     <div className="container">
                        <div className="copy">
                            <p className="link">&copy; SYSMOCART.COM , All rights reserved</p>
                        </div>
                    </div>
                </div> }
            </div>
        );
    }
}

function mapStateToProps(store){
    return {
        cartProducts: store.cart.cartProducts,
        cartCount: store.cart.cartCount,
        userData: store.userLogin.loginUser,
        isLoggedIn: store.userLogin.isLoggedIn,
        search: store.getProducts.search,
        searchLoading: store.getProducts.searchLoading
    }
}

export default connect(mapStateToProps)(App)

