import React from 'react';
import { connect } from 'react-redux'
import { Route, Redirect } from 'react-router-dom';

// const PrivateRoute1 = ({ component: Component, ...rest }) => (
//   <Route {...rest} render={props => (
//     fakeAuth.isAuthenticated ? (
//       <Component {...props}/>
//     ) : (
//       <Redirect to={{
//         pathname: '/login',
//         state: { from: props.location }
//       }}/>
//     )
//   )}/>
// )

const PrivateRoute = props => {
  const { isLoggedIn, userData } = props;
  const Component = props.component;
  return (
    isLoggedIn ?
    <Route {...props.rest} render={props => (
        <Component {...props}/>
    )}/> :
     <Redirect to={{
      pathname: '/login',
      state: { from: props.location }
    }}/>
  )
}



function mapStateToProps(store){
  return {
    userData: store.userLogin.loginUser,
    isLoggedIn: store.userLogin.isLoggedIn
  }
}

export default connect(mapStateToProps)(PrivateRoute)