import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import * as actions from '../actions';
import { PulseLoader } from 'react-spinners';
import { isMobile } from '../Helper/Common'
import LazyLoad from 'react-lazy-load';
import { Helmet } from "react-helmet";
import { Image } from 'cloudinary-react';
import AlertContainer from 'react-alert';
import InfiniteScroll from "react-infinite-scroll-component";



class Products extends React.Component {
  state = {
    page: 1,
    isAdded: null,
    size: "One Size",
    showError: false,
  }

  componentDidMount() {
    let category = this.props.match.params.category ? this.props.match.params.category : 'All'
    if(category !== 'All') {
      category = category.replace(/-/g, ' ')
    }
    this.props.dispatch(actions.fetchProducts(category, 1, true, true));
    this.props.dispatch(actions.fetchFilters());
  }

  alertOptions = {
    offset: 14,
    position: 'top left',
    theme: 'dark',
    time: 5000,
    transition: 'scale'
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.match.params.category != this.props.match.params.category) {
      let category = nextProps.match.params.category ? nextProps.match.params.category : 'All'
      if(category !== 'All') {
        category = category.replace(/-/g, ' ')
      }
      this.props.dispatch(actions.fetchProducts(category, 1, true, true));
    }
  }

  loadMoreProducts = ()=> {
    let category = this.props.match.params.category ? this.props.match.params.category : 'All'
    if(category !== 'All') {
      category = category.replace(/-/g, ' ')
    }
    let newPage = this.state.page + 1
    this.setState({page: newPage })
    this.props.dispatch(actions.fetchProducts(category, newPage, false, false));
  }


  handleAddCart = (data)=> {
    if(this.state.size) {
      if(this.state.isAdded == data.id){
        // this.props.history.push("/checkout/cart");
      } else {
        const cartProducts = this.props.cartProducts ? this.props.cartProducts : [];
        // const isExist = _.find(cartProducts, function(o) { return o.productId == productId; });
        const findProduct = data;
        let pObject;
        const cartId = (findProduct.id+'#'+ this.state.size);
        const isCartExist = _.find(cartProducts, function(o) { return o.cartId == cartId; });

        if(isCartExist == undefined || isCartExist == null){
          pObject = {
            productId: findProduct.id,
            defaultImage: findProduct.default_image,
            cartId: cartId,
            qty: 1,
            Product: findProduct,
            size: this.state.size
          }
          cartProducts.push(pObject)

        } else {
            // for(let i=0; i<cartProducts.length; i++){
            //   if(cartProducts[i].cartId == cartId){
            //     cartProducts[i].qty = cartProducts[i].qty + 1;
            //   }
            // }
        }

        this.props.dispatch(actions.handleAddCart(cartProducts));
        this.msg.show('Added Product To Cart', {
          time: 2000,
          type: 'success'
        })
      }
      this.setState({isAdded: data.id});
     } else {

      if(!this.state.size) {
        this.setState({showError: true});
        setTimeout(() => {
          this.setState({showError: false});
        }, 2000)
      }
    }

  }


  render() {
    const { Products, cartCount, isProductLoading, filters, filterLoading } = this.props;
    return(
      <div className={isMobile() ? '' : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
        <Helmet>
          <meta charSet="utf-8" />
          <title>Buy Grocery Online</title>
          <meta name="description" content="Sysmocart | Buy Grocery Online, Online Grocery, Grocery Store, Online Grocery Shopping, Online Grocery Store, Online Supermarket, Free Delivery, Great Offers, Best Prices" />
          <meta name="keywords" content="Sysmocart | Buy Grocery Online, Online Grocery, Grocery Store, Online Grocery Shopping, Online Grocery Store, Online Supermarket, Free Delivery, Great Offers, Best Prices" />
       </Helmet>
        <div className="women_main" style={isMobile() ? {marginTop: 0} : null}>
          { !isMobile() && !isProductLoading &&
          <div className="col-md-3">
            <div className="w_sidebar">
              <div className="w_nav1">
                <ul>
                   { filters && filters.category && filters.category.map((data, index)=>
                    <li style={this.props.match.params.category && this.props.match.params.category.replace(/-/g, ' ') == data.category ? {fontWeight: 600,color: '#589D3E'} : null} key={index}><Link to={data.category.replace(/ /g, '-')}>{data.category}</Link></li>
                   )}
                </ul> 
              </div>
              <section  className="sky-form">
                <h4>Brands</h4>
                <div className="row1 scroll-pane">
                  <div className="col col-4">
                    { filters && filters.brands && filters.brands.map((data, index)=>
                      <label key={index} className="checkbox"><input type="checkbox" name="checkbox" /><i></i>{data.soldBy}</label>                                            
                    )}
                  </div>
                </div>
              </section>
            </div>
          </div> }
          <div className={ isProductLoading ? 'col-md-12 w_content' : (isMobile() ? 'col-md-12 w_content' : 'col-md-9 w_content')}>
            {isProductLoading ?
            <div style={isProductLoading ? {textAlign: '-webkit-center', minHeight: '600px'} : null}>
               <PulseLoader
                color={'#56bfea'} 
                loading={isProductLoading} 
              />
            </div> :
            <div style={isMobile() ? {marginRight: 0, marginLeft: 0 } : null}>
              <InfiniteScroll
                dataLength={Products.length}
                next={this.loadMoreProducts}
                hasMore={true}
                className="row"
              >
                {Products && Products.map((data, key)=>{
                  const tageName = data.name.replace(/\s+/g, '-').toLowerCase();
                  const category  = data.category.replace(/\s+/g, '-').toLowerCase();
                  const discountPercent = ((data.mrp-data.discounted)/data.mrp*100).toFixed(0);

                  return(
                    <div key={key} className="grid1_of_4 col-sm-3" style={isMobile() ?  {width: '100%', textAlign: 'center'} : {textAlign: 'center'}}>
                      <div style={isMobile() ? {padding: 35} : {}} className="products-list content_box">
                          <Link to={`/${category}/${data.id}/${tageName}`}>
                              <div className="view view-fifth">
                              <LazyLoad height={150} offsetVertical={150}>
                                <Image cloudName="sysmocart" publicId={data.default_image} width={isMobile() ? '150' : '150'} quality="100" format="jpeg" crop="scale"/>
                              </LazyLoad>
                            </div>
                          </Link>
                           <p className="title-text">{data.name}</p>
                           <div className="price24">
                             <button onClick={ ()=> this.handleAddCart(data) } disabled={this.state.isAdded == data.id} className="add-bag-btn" style={{float: 'right', padding: 5, minWidth: 60, backgroundColor: '#ffffff', border: '1px solid #e9612587', color: '#e96125f2'}}>{this.state.isAdded == data.id ? 'ADDED' : 'ADD'}</button>
                             <span style={{float: 'left', marginTop: 6, fontSize: 16}}>
                               Rs. {data.discounted} {discountPercent > 0 && <span className="tag22">Rs. {data.mrp} </span>}{discountPercent > 0 && <span style={{color: '#ff5722', fontWeight: 100}}>({discountPercent}% OFF)</span>}
                             </span>
                             </div>
                        </div>
                    </div>
                  )
                })}
              </InfiniteScroll>
              <div className="clearfix"></div>
            </div>
            }
          </div>
          <div className="clearfix"></div>
          <AlertContainer ref={a => this.msg = a} {...this.alertOptions} />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (store) => {
    return {
      Products: store.getProducts.Products.products,
      cartCount: store.cart.cartCount,
      isProductLoading: store.getProducts.isProductLoading,
      filters: store.getProducts.filters,
      filterLoading: store.getProducts.filterLoading,
      cartProducts: store.cart.cartProducts
        // filter: state.filter
    };
};

export default connect(mapStateToProps)(Products)



