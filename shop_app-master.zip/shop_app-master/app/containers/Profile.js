import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
// import * as actions from '../actions/types';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {white, darkBlack} from 'material-ui/styles/colors';

import {Card, CardHeader, CardMedia, CardTitle, CardText} from 'material-ui/Card';

import {List, ListItem} from 'material-ui/List';
import Divider from 'material-ui/Divider';
import CommunicationCall from 'material-ui/svg-icons/communication/call';
import {indigo500} from 'material-ui/styles/colors';
import CommunicationEmail from 'material-ui/svg-icons/communication/email';
import { isMobile } from '../Helper/Common';

const muiTheme = getMuiTheme({
  palette: {
    textColor: darkBlack,
    alternateTextColor: white
  },
  appBar: {
    height: 50,
  },
});


class Profile extends React.Component {
    render() {
        const { userData, isLoggedIn } = this.props;
        return(
            <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
                <div className="order-main">
                    <MuiThemeProvider muiTheme={muiTheme}>
                        <Card>
                            <CardTitle subtitle="PROFILE" />
                            <CardText>
                                <List>
                                  <ListItem
                                    leftIcon={<CommunicationCall color={indigo500} />}
                                    primaryText={userData && userData.data.mobile}
                                    secondaryText="Mobile"
                                  />
                                </List>
                                <Divider inset={true} />
                                <List>
                                  <ListItem
                                    leftIcon={<CommunicationEmail color={indigo500} />}
                                    primaryText={userData && userData.data.email}
                                    secondaryText="Email"
                                  />
                                </List>
                            </CardText>
                          </Card>
                    </MuiThemeProvider>
                </div>
            </div>
        );
    }
}

function mapStateToProps(store){
    return {
        userData: store.userLogin.loginUser,
        isLoggedIn: store.userLogin.isLoggedIn
    }
}

export default connect(mapStateToProps)(Profile)
