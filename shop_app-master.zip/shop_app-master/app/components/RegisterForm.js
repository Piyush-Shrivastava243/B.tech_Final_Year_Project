import React from 'react'
import { Field, reduxForm } from 'redux-form'
import TextField from 'material-ui/TextField'
import { connect } from 'react-redux'
import CircularProgress from 'material-ui/CircularProgress';


const validate = values => {
  const errors = {}
  const requiredFields = ['email', 'password', 'mobile' ]
  requiredFields.forEach(field => {
    if (!values[ field ]) {
      errors[ field ] = 'Required'
    }
  })
  if (values.email && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = 'Please enter a valid email id'
  }

  if(values.mobile && !/^\d{10}$/.test(values.mobile)){
    errors.mobile = 'Please enter a valid mobile number (10 digits)'
  }

  if(values.password && values.password.length < 6 ){
    errors.password = 'Password must be at least 6 characters'
  }
  return errors
}

const renderTextField = ({ input, label, meta: { touched, error }, ...custom }) => (
  <TextField autoComplete="off" hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)

const RegisterForm = props => {
  const { handleSubmit, pristine, reset, valid, submitting, isRegistering } = props;
  return (
    <form onSubmit={handleSubmit}>
      <div>
        <Field name="email" component={renderTextField} label="Email"/>
      </div>
      <div>
        <Field name="password" type="password" component={renderTextField} label="Password"/>
      </div>
      <div>
        <Field name="mobile" component={renderTextField} label="Mobile"/>
      </div>
      <div>
        <button type="submit" style={isRegistering ?{padding: '9px'} : {}} className="login-login-button" disabled={pristine || submitting || !valid || isRegistering}>{isRegistering ? <CircularProgress size={25} thickness={5} /> : 'REGISTER' }</button>
      </div>
    </form>
  )
}

export default reduxForm({
  form: 'RegisterForm',  // a unique identifier for this form
  validate,
})(RegisterForm)