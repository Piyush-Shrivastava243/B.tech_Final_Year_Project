import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
// import * as actions from '../actions/types';


class PaymentFailed extends React.Component {
    render() {
        return(
            <div className="container fixed-top-margin">
                <div className="main">
                   Tariq
                </div>
            </div>
        );
    }
}

function mapStateToProps(store){
    return {}
}

export default connect(mapStateToProps)(PaymentFailed)
