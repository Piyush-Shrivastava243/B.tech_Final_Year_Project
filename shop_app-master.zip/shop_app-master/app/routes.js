import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Home from './containers/Home';
import About from './components/About';
import Products from './containers/Products';
import ProductDetails from './containers/ProductDetails';
import CheckoutCart from './containers/CheckoutCart';
import Login from './components/Login';
import Register from './components/Register';
import CheckoutAddress from './containers/CheckoutAddress';
import PaymentSuccess from './components/PaymentSuccess';
import PaymentFailed from './components/PaymentFailed';
import VerifyMobile from './containers/VerifyMobile';
import Profile from './containers/Profile';
import Orders from './containers/Orders';
import OrderDetails from './containers/OrderDetails';


import ForgetPassword from './components/ForgetPassword'

// import PrivateRoute from './components/PrivateRoute';

export default (
	<Switch>
		<Route exact path="/" component={Home} />
		<Route path="/about" component={About} />

		{/*<Route path="/product/custom-printed-tshirt" component={ProductDetails} />*/}
		<Route path="/login" component={Login} />
		<Route path="/password" component={ForgetPassword} />
		<Route path="/register" component={Register} />
		<Route path="/checkout/cart" component={CheckoutCart} />
		<Route path="/checkout/address" component={CheckoutAddress} />
		<Route path="/payment/success" component={PaymentSuccess} />
		<Route path="/payment/failed" component={PaymentFailed} />
		<Route path="/my/verify" component={VerifyMobile} />
		<Route path="/my/profile" component={Profile} />
		<Route path="/my/orders/:orderId" component={OrderDetails} />
		<Route path="/my/orders" component={Orders} />

		<Route path="/:category/:productId" component={ProductDetails} />
		<Route path="/:category" component={Products} />
		
	</Switch>
);
