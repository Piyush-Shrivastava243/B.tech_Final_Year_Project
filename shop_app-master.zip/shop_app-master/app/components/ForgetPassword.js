import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
import Snackbar from 'material-ui/Snackbar';
import { Link } from 'react-router-dom';
import { isMobile } from '../Helper/Common';
import TextField from 'material-ui/TextField'
import CircularProgress from 'material-ui/CircularProgress';


import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {cyan500, cyan700,  pinkA200,  grey100, grey300, grey400, grey500,  white, darkBlack, fullBlack,} from 'material-ui/styles/colors';

const muiTheme = getMuiTheme({
  palette: {
    textColor: darkBlack,
    alternateTextColor: white
  },
  appBar: {
    height: 50,
  },
});


class ForgetPassword extends React.Component {
    state = {
        mobile: null,
        otp: null,
        newPassword: null,
        isOtpSent: false,
        isLoading: false,
        userMobile: null
    }
    componentDidMount() {
        if(this.props.isLoggedIn){
            this.props.history.push("/products");
        }
    }

    handleChange = (e) => {
        const name = e.target.name;
        this.setState({[name]: e.target.value})
    }

    sendOneTimePassword = ()=> {
        this.setState({ isLoading: true});
        const values = {
            userid: this.state.mobile
        }
        this.props.dispatch(actions.sendChangePasswordOtp(values, (res) => {
            if (!res.isSuccess) {
                this.setState({ open: true, message: res.error, isLoading: false});
            } else {
                this.setState({ isOtpSent: true, isLoading: false, userMobile: res.mobile });
            }
        }))
    }

    changePassword = ()=> {
        this.setState({ isLoading: true});
        const values = {
            mobile: this.state.userMobile,
            otp: this.state.otp,
            newPassword: this.state.newPassword
        }
        this.props.dispatch(actions.handleChangePassword(values, (res) => {
            if (!res.isSuccess) {
                this.setState({ open: true, message: res.error, isLoading: false});
            } else {
                this.setState({
                    open: true, message: 'Password Successfully Updated', isLoading: false, otp: '', newPassword: '', mobile: '', isOtpSent: false
                })
            }
        }))
    }

    render() {
        const isMobileValid = /^\d{10}$/.test(this.state.mobile);
        return(
            <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
                <div className="login-main">
                    <div className="login-box" style={{width: '280px'}}>
                        <MuiThemeProvider muiTheme={muiTheme}>
                            <div>
                                { this.state.isOtpSent &&
                                <div style={{textAlign: 'left'}}>
                                    <b>OTP Sent to *****{this.state.userMobile.substr(this.state.userMobile.length - 4)}</b>
                                </div> }
                                { !this.state.isOtpSent ?
                                <TextField
                                   hintText="Email or Mobile"
                                   floatingLabelText="Email or Mobile"
                                   value={this.state.mobile}
                                   onChange={this.handleChange}
                                   name="mobile"
                                /> :
                                <div>
                                    <TextField
                                       hintText="Enter OTP"
                                       floatingLabelText="Enter OTP"
                                       value={this.state.otp}
                                       onChange={this.handleChange}
                                       name="otp"
                                    />
                                    <TextField
                                        hintText="Enter New Password"
                                        floatingLabelText="Enter New Password"
                                        value={this.state.newPassword}
                                        onChange={this.handleChange}
                                        name="newPassword"
                                    />
                                </div> }
                                <div>
                                {!this.state.isOtpSent ?
                                    <button onClick={this.sendOneTimePassword} type="submit" className="login-login-button">{this.state.isLoading ? <CircularProgress size={25} thickness={5} /> : 'Request OTP' }</button> :
                                    <button onClick={this.changePassword} type="submit" className="login-login-button">{this.state.isLoading ? <CircularProgress size={25} thickness={5} /> : 'Update Password' }</button>
                                }
                                </div>
                                <div className="login-link-container">
                                    <div className="login-right-links">
                                        <Link to="/login" className="login-create-account-link login-link">Back to login</Link>
                                    </div>
                                </div>
                                <Snackbar
                                  open={this.state.open}
                                  message={this.state.message}
                                  autoHideDuration={3000}
                                  onRequestClose={() => this.setState({ open: false })}
                                />
                            </div>
                        </MuiThemeProvider>
                        <div className="clearfix"></div>
                    </div>
                    
                </div>
            </div>
        );
    }
}

function mapStateToProps(store){
    return {
        isLoggedIn: store.userLogin.isLoggedIn,
        sendingForget: store.userLogin.sendingForget,
        isPasswordChanges: store.userLogin.isPasswordChanges
    }
}

export default connect(mapStateToProps)(ForgetPassword)
