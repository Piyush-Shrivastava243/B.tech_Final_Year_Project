import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
// import * as actions from '../actions/types';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {white, darkBlack} from 'material-ui/styles/colors';

import {Card, CardHeader, CardMedia, CardTitle, CardText} from 'material-ui/Card';
import Avatar from 'material-ui/Avatar';
import CircularProgress from 'material-ui/CircularProgress';
import { Image } from 'cloudinary-react';


import {List, ListItem} from 'material-ui/List';
import Divider from 'material-ui/Divider';
import CommunicationCall from 'material-ui/svg-icons/communication/call';
import {indigo500} from 'material-ui/styles/colors';
import CommunicationEmail from 'material-ui/svg-icons/communication/email';
import { isMobile } from '../Helper/Common';

import moment from 'moment';

const muiTheme = getMuiTheme({
  palette: {
    textColor: darkBlack,
    alternateTextColor: white
  },
  appBar: {
    height: 50,
  },
});


class OrderDetails extends React.Component {
    componentDidMount() {
      const orderId = this.props.match.params.orderId;
      this.props.dispatch(actions.fetchSingleOrders(orderId));
    }
    render() {
        const { userData, isLoggedIn, orders, isOrderFetching } = this.props;
        const ordersDetails = orders && orders.orders;

        const orderStatus = (status)=> {
            switch(status) {
                case '0':
                    return 'Payment Pending';
                    break;
                case '1':
                    return 'Order Placed';
                    break;
                case '2':
                    return 'Delivered';
                    break;
                default:
                    return 'Order Failed';
            }
        }
        return(
          <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
              <div className="order-main">
                  <MuiThemeProvider muiTheme={muiTheme}>
                      <Card>
                        <CardHeader
                          subtitle="ORDERS DETAILS"
                        />
                        {isOrderFetching ?
                        <div style={{textAlign: 'center'}}>
                            <CircularProgress />
                        </div> :
                        <CardText>
                          <div>
                            {ordersDetails && ordersDetails.length == 0 &&
                            <div style={{textAlign: 'center'}}>
                                <b>No Order Found</b>
                            </div>}
                            <List>
                            {ordersDetails && ordersDetails.map((data, index)=> {
                              const productsArr = JSON.parse(data.user_products);
                              const address = JSON.parse(data.user_address);
                              let prod = [];
                              for(let i=0; i<productsArr.length;i++) {
                                  prod.push(
                                    <ListItem
                                        key={i}
                                        value={2}
                                        primaryText={productsArr[i].ProductName}
                                        leftAvatar={<Image cloudName="sysmocart" style={{ borderRadius: 0, height: '53px', border: '1px solid rgb(223, 223, 223)'}} publicId={productsArr[i].defaultImage} quality="100" format="jpeg" crop="scale"/>}
                                        secondaryText={
                                            <p>
                                                <span style={{color: darkBlack}}>Size: {productsArr[i].Size} / Qty:{productsArr[i].Quantity}</span><br />
                                                <small>&#8377; <b>{productsArr[i].Price} </b></small>
                                            </p>
                                        }
                                      secondaryTextLines={2}
                                    />
                                  )
                              }
                              return(
                                <div key={index}>
                                    <ListItem
                                        value={1}
                                        secondaryText={
                                            <p>
                                                <span style={{color: darkBlack}}>ORDER NO: <b>{data.id} {isMobile() ? null : data.status == 1 ? ('- '+ data.order_id) : null}</b></span><br />
                                                <span>Total Amount Paid <b>&#8377; {data.payment_amount} </b></span>
                                                <span className={data.status == 0 ? 'label label-danger' : 'label label-success'}>{orderStatus(data.status)}</span>
                                            </p>
                                        }
                                        secondaryTextLines={2}
                                        initiallyOpen={true}
                                        nestedItems={prod}
                                        rightIcon={null}
                                        rightAvatar={null}
                                      />
                                    {orders.length-1 == index ? null :  <Divider inset={true} />}
      
                                    <div>
                                      <div style={{padding: '10px 0 10px', color: '#94969f'}}>Shipping Address:</div>
                                      <span style={{color: darkBlack}}>{address.name}</span><br />
                                      <div>
                                        {address.address}
                                        </div>
                                        <div>
                                          {`${address.city}, ${address.state}, ${address.pincode}`}
                                        </div>
                                        <div>
                                          {`${address.mobile}`}
                                        </div>
                                    </div>

                                    <div>
                                      <div style={{padding: '10px 0 10px', color: '#94969f'}}>Order Date: {moment(data.order_datetime).format('MMMM Do YYYY, h:mm:ss A')}</div>
                                    </div>
                                </div>
                              )
                            })}
                            </List>
                          </div>
                        </CardText>}
                      </Card>
                  </MuiThemeProvider>
              </div>
            </div>
        );
    }
}

function mapStateToProps(store){
    return {
        userData: store.userLogin.loginUser,
        isLoggedIn: store.userLogin.isLoggedIn,
        orders: store.getProducts.Orders,
        isOrderFetching: store.getProducts.isOrderFetching
    }
}

export default connect(mapStateToProps)(OrderDetails)
