import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';

class CartEditModal extends React.Component {

  render() {
    const actions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onClick={this.props.close}
      />,
      <FlatButton
        label="Discard"
        primary={true}
        onClick={this.props.close}
      />,
    ];
    return (
        <Dialog
          actions={actions}
          modal={true}
          open={this.props.open}
          onRequestClose={this.props.close}
        >
          Discard draft?
        </Dialog>
    )
  }
}


export default CartEditModal