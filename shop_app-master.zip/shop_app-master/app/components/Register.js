import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
import Snackbar from 'material-ui/Snackbar';
import queryString from 'query-string';
import { reset } from 'redux-form';
import RegisterForm from './RegisterForm';
import { Link } from 'react-router-dom';
import { isMobile } from '../Helper/Common';


import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {cyan500, cyan700,  pinkA200,  grey100, grey300, grey400, grey500,  white, darkBlack, fullBlack,} from 'material-ui/styles/colors';

const muiTheme = getMuiTheme({
  palette: {
    textColor: darkBlack,
    alternateTextColor: white
  },
  appBar: {
    height: 50,
  },
});


class Register extends React.Component {
    state ={
        open: false,
        message: '',
        isRegistering: false
    }

    componentDidMount() {
        this.props.dispatch(reset('RegisterForm'));
        if(this.props.isLoggedIn){
            this.props.history.push("/products");
        }
    }

    componentWillReceiveProps(nextProps){
        const parsed = queryString.parse(this.props.location.search);
        if(nextProps.isLoggedIn && !this.props.isLoggedIn){
            this.props.history.push(parsed.next ? parsed.next : '/my/verify');
        }
    }

    handleRegister = (values) => {
        this.setState({isRegistering: true})
        this.props.dispatch(actions.userRegisteration(values, (res)=> {
            if(!res.isSuccess){
                this.props.dispatch(reset('RegisterForm'));
                this.setState({ open: true, message: res.error.error});
            }
            this.setState({isRegistering: false})
        }))
    }


    render() {
        return(
            <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
                 <div className="login-main">
                    <div className="login-box">
                        <MuiThemeProvider muiTheme={muiTheme}>
                            <div>
                                <RegisterForm onSubmit={this.handleRegister} isRegistering={this.state.isRegistering} />
                                <div className="register-already-account-main">
                                    <div className="register-already-div">
                                        <span className="register-already-text">Already have an account?</span>
                                        <Link to="/login" className="register-already-account">Login!</Link>
                                    </div>
                                </div>
                                <Snackbar
                                  open={this.state.open}
                                  message={this.state.message}
                                  autoHideDuration={3000}
                                  onRequestClose={() => this.setState({ open: false })}
                                />
                            </div>
                        </MuiThemeProvider>
                    </div>
                </div>
                <div className="clearfix"></div>
            </div>
        );
    }
}

function mapStateToProps(store){
    return {
        userData: store.userLogin.loginUser,
        isLoggedIn: store.userLogin.isLoggedIn,
        RegisterError: store.userLogin.RegisterError
    }
}

export default connect(mapStateToProps)(Register)
