import React from 'react';
import { Link } from 'react-router-dom';
import Routes from '../routes';
import { connect } from 'react-redux';
import * as actions from '../actions';
import { browserHistory } from 'react-router-dom';
import AlertContainer from 'react-alert';
import _ from 'lodash';
import FaCartPlus from 'react-icons/lib/fa/cart-plus';
import FaClose from 'react-icons/lib/fa/close';
import ArrowRight from 'react-icons/lib/fa/arrow-right';
import { PacmanLoader } from 'react-spinners';
import { isMobile } from '../Helper/Common';
import { Carousel, OverlayTrigger, Tooltip } from 'react-bootstrap';
import IconButton from 'material-ui/IconButton';
import FaUser from 'react-icons/lib/fa/user';
import Countdown from '../Helper/Countdown'

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {white, darkBlack, blue300, indigo900} from 'material-ui/styles/colors';
import Avatar from 'material-ui/Avatar';
import Chip from 'material-ui/Chip';

const muiTheme = getMuiTheme({
  palette: {
    textColor: darkBlack,
    alternateTextColor: white
  }
});

const styles = {
  chip: {
    margin: 4,
  },
  wrapper: {
    display: 'flex',
    flexWrap: 'wrap',
  },
};

const DataBranch = [
  'Blank',
  'CSE',
  'MECH',
  'CIVIL',
  'EEE',
  'BCOM',
  'MCOM',
  'BSC',
  'MSC',
  'BCA',
  'MCA',
  'BBA',
  'MBA',
  'MBBS',
  'MEDICAL',
  'BIOTECH',
  'BIOSC'
];


class ProductDetails extends React.Component {
  state = {
    isAdded: false,
    size: null,
    showError: false,
    showErrorColors: false,
    color: 1,
    hasLogo: true,
    hasSideLogo: true,
    hasBackText: true
  }
  componentDidMount() {
    this.props.dispatch(actions.fetchProducts());
  }

  alertOptions = {
    offset: 14,
    position: 'top left',
    theme: 'dark',
    time: 5000,
    transition: 'scale'
  }

  handleRadioSize = (size) => {
    this.setState({size: size})
  }

  handleColors = (color)=> {
    this.setState({color: color});
  }

  handleCustom = () => {
    this.setState({hasLogo: true, hasSideLogo: true, hasBackText: true});
  }

  handleAddCart = ()=> {
    if(this.state.size && this.state.color) {
      if(this.state.isAdded){
        this.props.history.push("/checkout/cart");
      } else {
        const cartProducts = this.props.cartProducts ? this.props.cartProducts : [];
        const productId = 1001;

        // const isExist = _.find(cartProducts, function(o) { return o.productId == productId; });
        const findProduct = this.props.Products[0];
        let pObject;
        const cartId = (productId+'#'+ this.state.size+'#'+this.state.color);
        const isCartExist = _.find(cartProducts, function(o) { return o.cartId == cartId; });

        if(isCartExist == undefined || isCartExist == null){
          pObject = {
            productId: productId,
            defaultImage: ('/static/items/' + this.state.color + '.png'),
            cartId: cartId,
            qty: 1,
            Product: findProduct,
            size: this.state.size,
            color: this.state.color,
            hasLogo: this.state.hasLogo,
            hasBackText: this.state.hasBackText,
            hasSideLogo: this.state.hasSideLogo
          }
          cartProducts.push(pObject)

        } else {
            for(let i=0; i<cartProducts.length; i++){
              if(cartProducts[i].cartId == cartId){
                cartProducts[i].qty = cartProducts[i].qty + 1;
              }
            }
        }

        const conter = (this.props.cartCount ? this.props.cartCount : 0) + 1;
        this.props.dispatch(actions.handleAddCart(conter, cartProducts));
        this.msg.show('Added Product To Cart', {
          time: 2000,
          type: 'success'
        })
      }
      this.setState({isAdded: true});
     } else {

      if(!this.state.color) {
          this.setState({showErrorColors: true});
          setTimeout(() => {
            this.setState({showErrorColors: false});
          }, 2000)
      }

      if(!this.state.size) {
        this.setState({showError: true});
        setTimeout(() => {
          this.setState({showError: false});
        }, 2000)
      }
    }

  }
  goToBag = ()=> {
    window.location.href = '/checkout/cart';
  }

  render() {
    const { cartCount, Products, isProductLoading } = this.props;
    const productId = this.props.match.params.productId;
    const productDetails = Products && Products[0];

    let hasUndoBtton = (this.state.hasLogo && this.state.hasBackText && this.state.hasSideLogo);
    const tooltip = (color)=> (
      <Tooltip id="tooltip">
        <strong>{color}</strong>
      </Tooltip>
    );

    const tooltipSize = (size)=> (
      <Tooltip id="tooltip">
        <strong>{size}</strong>
      </Tooltip>
    );

    const colorImageRender = (color)=> {
      switch (color) {
        case 1:
            return ['/static/items/1.png'];
            break; 
        case 2:
            return ['/static/items/2.png'];
            break; 
        case 3:
            return ['/static/items/3.png'];
            break;
        case 4:
            return ['/static/items/4.png'];
            break;
        case 5:
            return ['/static/items/5.png'];
            break;
        case 6:
            return ['/static/items/6.png'];
            break;
        default: 
            return ['/static/items/1.png'];
      }
    }

    let hasAnError = false;
    if(this.state.showError) {
      hasAnError = true;
    }

    if(this.state.showErrorColors) {
      hasAnError = true;
    }

    const OPTIONS = { endDate: '02/22/2018 11:59 PM'}

    return(
      <div className={isMobile() ? null : 'container fixed-top-margin'}>
        <div className="women_main">
          <div className="row single" style={isMobile() ? {marginRight: 0, marginLeft: 0 } : null}>
            <div className="col-md-12">
              {isProductLoading ?
              <div style={isProductLoading ? {textAlign: '-webkit-center', minHeight: '600px'} : null}>
                <PacmanLoader
                  color={'#123abc'} 
                  loading={isProductLoading} 
                />
              </div> :
              <div>
                <div className="single_left">
                  <div className={isMobile()  ? null : 'col-md-4'}>
                    <Carousel>
                      {colorImageRender(this.state.color).map((image, key) => {
                        return (
                          <Carousel.Item key={key}>
                            <img width={900} height={500} alt="900x500" src={image} />
                          </Carousel.Item>
                        )
                      })}
                    </Carousel>
                    <p style={{paddingTop: '10px', fontSize: '10px'}}>Color may vary from the picture | Sold By: <b>SYSMOCART</b></p>
                    <div className="clearfix"></div>       
                  </div>
                  <div className={isMobile() ? null : 'desc1 span_3_of_2'}>
                    <h3>{productDetails && productDetails.ProductName}</h3>
                    <h2 className="pdp-discount-container"><s>₹{productDetails && productDetails.OriginalPrice}</s><span className="pdp-discount">({productDetails && productDetails.Discount}% OFF)</span></h2>
                    <p>₹{productDetails && productDetails.Price}</p>
                    {/*<span className="count-down-text">Extra ₹40 discount ends in less than  <Countdown options={OPTIONS} /></span>*/}
                    <div className="det_nav1">
                      <h4>Select a size :</h4>
                      <div className="sky-form col col-4 select-sizes">
                          <ul style={{paddingTop: '5px'}} className={this.state.showError ? 'shake-btn' : ''}>
                              <OverlayTrigger placement="top" overlay={tooltip('S (36)')}>
                                <li className={this.state.size == 36 ? 'selected' : null} onClick={()=> this.handleRadioSize(36)}>
                                  <span>36</span>
                                </li>
                              </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('M (38)')}>
                                <li className={this.state.size == 38 ? 'selected' : null} onClick={()=> this.handleRadioSize(38)}>
                                  <span>38</span>
                                </li>
                              </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('L (40)')}>
                                <li className={this.state.size == 40 ? 'selected' : null} onClick={()=> this.handleRadioSize(40)}>
                                  <span>40</span>
                                </li>
                              </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('XL (42)')}>
                                <li className={this.state.size == 42 ? 'selected' : null} onClick={()=> this.handleRadioSize(42)}>
                                  <span>42</span>
                                </li>
                              </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('XXL (44)')}>
                                <li className={this.state.size == 44 ? 'selected' : null} onClick={()=> this.handleRadioSize(44)}>
                                  <span>44</span>
                                </li>
                              </OverlayTrigger>
                          </ul>
                          {this.state.showError && <span style={{color: 'red'}}><small><b>Please select a size</b></small></span>}
                      </div>
                    </div>
                    <div className="det_nav1">
                      <h4>Select a color :</h4>
                      <div className="sky-form col col-4 select-colors">
                          <ul style={{paddingTop:' 5px'}} className={this.state.showErrorColors ? 'shake-btn' : ''}>
                              <OverlayTrigger placement="top" overlay={tooltip('Black')}>
                                <li className={this.state.color == 1 ? 'selected' : null} onClick={()=> this.handleColors(1)}>
                                  <img src="/static/items/colors/color1.jpg" />
                                </li>
                              </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('Maroon')}>
                                <li className={this.state.color == 2 ? 'selected' : null} onClick={ ()=> this.handleColors(2)}>
                                  <img src="/static/items/colors/color2.jpg" />
                                </li>
                              </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('Grey')}>
                                <li className={this.state.color == 3 ? 'selected' : null} onClick={ ()=> this.handleColors(3)}>
                                  <img src="/static/items/colors/color3.jpg" />
                                </li>
                              </OverlayTrigger>
                              {!isMobile() &&
                              <OverlayTrigger placement="top" overlay={tooltip('Royal Blue')}>
                                <li className={this.state.color == 4 ? 'selected' : null} onClick={ ()=> this.handleColors(4)}>
                                  <img src="/static/items/colors/color4.jpg" />
                                </li>
                              </OverlayTrigger> }
                              {!isMobile() &&
                              <OverlayTrigger placement="top" overlay={tooltip('Navy Blue')}>
                                <li className={this.state.color == 5 ? 'selected' : null} onClick={ ()=> this.handleColors(5)}>
                                  <img src="/static/items/colors/color5.jpg" />
                                </li>
                              </OverlayTrigger> }
                              {!isMobile() &&
                              <OverlayTrigger placement="top" overlay={tooltip('White')}>
                                <li className={this.state.color == 6 ? 'selected' : null} onClick={ ()=> this.handleColors(6)}>
                                  <img src="/static/items/colors/color6.jpg" />
                                </li>
                              </OverlayTrigger> }

                          </ul>
                          {isMobile() &&
                          <ul style={{paddingTop:' 5px'}} className={this.state.showErrorColors ? 'shake-btn' : ''}>
                              <OverlayTrigger placement="top" overlay={tooltip('Sky Blue')}>
                                <li className={this.state.color == 4 ? 'selected' : null} onClick={ ()=> this.handleColors(4)}>
                                  <img src="/static/items/colors/color4.jpg" />
                                </li>
                               </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('Navy Blue')}>
                                <li className={this.state.color == 5 ? 'selected' : null} onClick={ ()=> this.handleColors(5)}>
                                  <img src="/static/items/colors/color5.jpg" />
                                </li>
                               </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('White')}>
                                <li className={this.state.color == 6 ? 'selected' : null} onClick={ ()=> this.handleColors(6)}>
                                  <img src="/static/items/colors/color6.jpg" />
                                </li>
                              </OverlayTrigger>
                          </ul> }
                          {this.state.showErrorColors && <span style={{color: 'red'}}><small><b>Please select a color</b></small></span>}
                      </div>
                    </div>
                    <div className="det_nav1">
                      <h4>Customise Design :</h4>
                      <div className="sky-form col col-4 select-colors">
                          <ul style={{paddingTop:' 5px'}} className={this.state.showErrorColors ? 'shake-btn' : ''}>
                              <OverlayTrigger placement="top" overlay={tooltip('Front')}>
                                <li>
                                  <img width="50" src="/static/images/thum1.jpg" />
                                </li>
                              </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('Side')}>
                                <li>
                                  <img width="50" src="/static/images/thum2.jpg" />
                                </li>
                              </OverlayTrigger>
                              <OverlayTrigger placement="top" overlay={tooltip('Back')}>
                                <li>
                                  <img width="50" src="/static/images/thum3.jpg" />
                                </li>
                              </OverlayTrigger>
                              { !hasUndoBtton && 
                              <li onClick={ ()=> this.handleCustom()}>
                                  <img width="50" src="/static/images/undo.png" />
                               </li> }
                          </ul>
                      </div>
                    </div>
                    <MuiThemeProvider muiTheme={muiTheme}>
                    <div>
                      <div className="det_nav1" style={{marginTop: '5px'}}>
                      {this.state.hasLogo &&
                        <Chip
                          onRequestDelete={()=> this.setState({hasLogo: false})}
                          labelStyle={{fontSize: "12px", marginRight: '19px'}}
                        >
                          Logo Printed On Front 
                        </Chip> }
                        </div>
                        <div className="det_nav1" style={{marginTop: '5px'}}>
                          {this.state.hasBackText &&
                          <Chip
                            onRequestDelete={()=> this.setState({hasBackText: false})}
                            labelStyle={{fontSize: "12px", marginRight: '7px'}}
                          >
                            Student Printed On Back
                          </Chip> }
                        </div>
                        <div className="det_nav1" style={{marginTop: '5px'}}>
                          {this.state.hasSideLogo &&
                          <Chip
                            onRequestDelete={ ()=> this.setState({hasSideLogo: false}) }
                            labelStyle={{fontSize: "12px", marginRight: '18px'}}
                          >
                            F2k18 Printed On Side 
                          </Chip> }
                        </div>
                    </div>
                    </MuiThemeProvider>
                    <AlertContainer ref={a => this.msg = a} {...this.alertOptions} />
                    <div className="btn_form">
                        <button onClick={ this.handleAddCart } className="add-bag-btn" href="/checkout/cart">{ this.state.isAdded ? <ArrowRight size={20} /> : <FaCartPlus size={20} />} {this.state.isAdded ? 'GO TO CART' : 'ADD TO BAG'}</button>
                        { hasAnError &&
                        <h6 style={{marginTop: '5px', color: 'red'}}>Required Above Fields</h6> }
                    </div>
                  </div>
                  <div className="clearfix"></div>
                </div>
                <div className="single-bottom1">
                  <h6>Details</h6>
                  <p className="prod-desc">{productDetails && productDetails.Description}</p>
                </div>
              </div> }
            </div> 
          <div className="clearfix"></div>     
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(store){
  return {
    cartCount: store.cart.cartCount,
    cartProducts: store.cart.cartProducts,
    Products: store.getProducts.Products.products,
    isProductLoading: store.getProducts.isProductLoading
  }
}

export default connect(mapStateToProps)(ProductDetails)

