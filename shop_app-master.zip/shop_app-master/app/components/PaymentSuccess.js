import React from 'react';
import * as actions from '../actions';
import { connect } from 'react-redux';
import queryString from 'query-string';
import request from 'superagent';
import { isMobile } from '../Helper/Common';


// import * as actions from '../actions/types';


class PaymentSuccess extends React.Component {

    componentDidMount() {
      setTimeout( ()=> { 
        this.props.dispatch(actions.emptyCartData());
      }, 2000);
    } 


    render() {
        const parsed = queryString.parse(this.props.location.search);
        return(
            <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
                <div className="main">
                   <div className="shoping_bag1">
                        <div className="order-confirm">
                          <div className="badge"></div>
                          <article>
                            <div className="wrap">
                              <div className="icon-success"></div>
                              <div className="msg-success">Order Confirmed</div>
                              <div className="msg-num"> Payment Id: <strong>{parsed && parsed.payment_id}</strong>
                                <div className="msg-tip"><span className="tip">TIP:</span>Manage your orders from the 'My Orders' section.</div>
                              </div>
                            </div>
                          </article>
                          <div className="msg-fraud"><span className="note">Note:&nbsp;</span>We do not demand your banking and credit card details verbally or telephonically.
                            Please do not divulge your details to fraudsters and imposters falsely claiming to be calling on SysmoCart's behalf.
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

function mapStateToProps(store){
    return {}
}

export default connect(mapStateToProps)(PaymentSuccess)
