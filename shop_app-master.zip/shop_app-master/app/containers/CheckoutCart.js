import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import * as actions from '../actions';
import swal from 'sweetalert'
import _ from 'lodash';
import { isMobile, validateCart } from '../Helper/Common';
import { Modal } from 'react-bootstrap';
import { Image } from 'cloudinary-react';
import { PulseLoader } from 'react-spinners';




class CheckoutCart extends React.Component {

    state = {
        open: false,
        quantity: 0,
        selected: 1,
        cartId: null
    }


    componentWillMount() {
      if(this.props.cartProducts.length) {
        const cartnew = this.props.cartProducts;
        this.props.dispatch(actions.validateProducts(_.uniq(_.map(cartnew, 'productId'))))
      }
    }

    componentWillReceiveProps(nextProps) {
      if(!this.props.cartProducts.length && nextProps.cartProducts.length) {
        const cart = nextProps.cartProducts;
        this.props.dispatch(actions.validateProducts(_.uniq(_.map(cart, 'productId'))))
      }

      if(nextProps.cartProducts.length) {
        if(this.props.cartCount !== nextProps.cartCount) {
          const cartnew = nextProps.cartProducts;
          this.props.dispatch(actions.validateProducts(_.uniq(_.map(cartnew, 'productId'))))
        }
      }
    }


    handleCartRemove = (productId, qty)=> {
        this.props.dispatch(actions.handleCartRemove(productId, qty));
    }

    handleModal = (quantity, selected, cartId) => {
      this.setState({open: true, quantity: quantity, selected: selected, cartId: cartId});
    }


    handleClose = (quantity) => {
      this.setState({open: false});
    }


    handleChange = (count, cartId) => {
      this.setState({selected: count, open: false})
      this.props.dispatch(actions.changeCartQuantity(parseInt(count), cartId));
    }

    handleCheckoutAddress = ()=> {

      const cartnew = this.props.cartProducts;
      let that = this;
      this.props.dispatch(actions.validateProducts(_.uniq(_.map(cartnew, 'productId')), ()=> {
        console.log(that.props.cartProducts, that.props.liveCartItems)
        if(validateCart(that.props.cartProducts, that.props.liveCartItems)) {
          that.props.history.push("/checkout/address")
        } else {
          swal("Please remove out of stock items from your bag.");
        }   

      }))

    }


    validateProducts = (id)=> {
      return _.find(this.props.liveCartItems.products, { 'id': id });
    }

    renderSizes = ()=> {
      let n = this.state.quantity > 10 ? 10 : this.state.quantity;
      return n < 1 ? <div style={{textAlign: 'center',padding: 50,color: 'red'}}>OUT OF STOCK</div> : [...Array(parseInt(n))].map((e, i) => <a style={{cursor: 'pointer', borderRadius: 0}} key={i} onClick={()=> this.handleChange(i+1, this.state.cartId)} className="list-group-item">{i+1} {this.state.selected == i+1 && <span style={{float: 'right', fontSize: 20, color: 'green'}}>&#10004;</span> }</a>)
    }

    render() {
        const { Products, cartCount, cartProducts, liveCartItems, validatingCart } = this.props;

        let TotalPrice = 0;

        // if(cartProducts.length) {
        //   for(let i=0; i<cartProducts.length;i++){
        //       TotalPrice += (this.validateProducts(cartProducts[i].productId) && this.validateProducts(cartProducts[i].productId).discounted*cartProducts[i].qty);
        //   } 
        // }

        if(cartProducts.length && liveCartItems.products && liveCartItems.products.length) {
          for(let i=0; i<cartProducts.length;i++){
              TotalPrice += _.find(liveCartItems.products, { 'id': cartProducts[i].productId }) && _.find(liveCartItems.products, { 'id': cartProducts[i].productId }).discounted*cartProducts[i].qty;
          }  
        }

        return(
            <div className={isMobile() ? null : 'container fixed-top-margin'} style={isMobile() ? {marginTop: 75} : null}>
                <div className="main" style={isMobile() ? {padding: '10px'} : null}>
                    { cartCount < 1 ?
                    <div className="shoping_bag1">
                        <div className="empty-cart-icon"></div>
                        <br />
                        <div className="empty-cart-text">Your Shopping Bag is empty</div>
                    </div>
                    :
                    <div style={{minHeight: 500}}>
                      {validatingCart ?
                        <div style={{textAlign: '-webkit-center', minHeight: '600px'}}>
                          <PulseLoader
                            color={'#56bfea'} 
                            loading={true} 
                          />
                        </div> :
                      <div>
                        <div className="col-md-7">
                            <div className="shoping_bag">
                                <h4><img src="/static/images/bag1.png" />my shopping bag / <span> {cartCount} item</span></h4>
                                <div className="clearfix"></div>
                            </div>
                            {cartProducts && cartProducts.map((data, index)=> {
                                const liveData = this.validateProducts(data.productId)
                                const quantity = liveData && JSON.parse(liveData.sizes);
                                const availableItems = _.find(quantity, { 'label': data.size });
                                const inStock = availableItems && liveData.in_stock == 1 && liveData.isActive == 0 && availableItems.count > 0 ? true : false;
                                const isValidQuantity = availableItems && parseInt(availableItems.count) >= parseInt(data.qty) ? false : true;
                                
                                const tageName = liveData && liveData.name.replace(/\s+/g, '-').toLowerCase();
                                const category  = liveData && liveData.category.replace(/\s+/g, '-').toLowerCase();
                                return(
                                    <div key={index} className="shoping_bag1" style={isValidQuantity ? {border: '1px solid #ff57227d'} : null}>
                                        <div className="shoping_left">
                                            <div className="shoping1_of_1">
                                                <Link to={`/${category}/${data.productId}/${tageName}`}><Image style={{padding: 3}} cloudName="sysmocart" publicId={liveData && liveData.default_image} width="60" format="jpeg" quality="90" crop="scale"/></Link>
                                            </div>
                                            <div className="shoping1_of_2">
                                                <h4><Link to={`/${category}/${data.productId}/${tageName}`}>{liveData && liveData.name}</Link> </h4>
                                                <span>size <b>{data.size}</b>&nbsp;&nbsp; qty <b>{data.qty}</b></span>
                                                <ul className="s_icons">
                                                  <li><a onClick={()=> this.handleModal(availableItems.count, data.qty, data.cartId)}><img src="/static/images/s_icon1.png" alt="" /></a></li>
                                                  {/*<li><a href="#"><img src="/static/images/s_icon2.png" alt="" /></a></li>*/}
                                                  <li><a onClick={()=> this.handleCartRemove(data.cartId, data.qty)} href="#"><img src="/static/images/s_icon3.png" alt="" /></a></li>
                                                </ul>
                                            </div>
                                            <div className="clearfix"></div>
                                        </div>
                                        {isValidQuantity && <span style={{float: 'right', color: 'red', fontSize: 9}}>{inStock ? `Quantity Not Available - ${availableItems.count} Left` : 'This item is out of stock'}</span> }
                                        
                                        <div className="shoping_right" style={isMobile() ? {float: 'right'} : null}>
                                            <p>{/*35% off */}&nbsp;<span> Rs. {liveData && liveData.discounted*data.qty}</span></p>
                                        </div>
                                        <div className="clearfix"></div>
                                    </div>
                                )
                            })}
                        </div>
                        <div className="col-md-5">
                          <div style={{display: 'flex'}}>
                            <input style={{marginTop: 10, height: 35, borderRadius: 0}} type="text" className="form-control" placeholder="Enter Promo Code" />
                            <button style={{borderRadius: 0, height: 35}} className="im-checkout-btn">Apply</button>
                          </div>
                          <div className="registration_form">
                            <div className="clearfix"></div>
                              <ul className="list-group">
                                  <li className="list-group-item">
                                  <span>Delivery</span>
                                    <span style={{float: 'right'}}>Free</span>
                                  
                                  </li>
                                  <li className="list-group-item">
                                    <b>
                                      <span>Total Payable</span>
                                      <span style={{float: 'right'}}>Rs. {TotalPrice}</span>
                                    </b>
                                  </li>
                              </ul>
                            </div>
                           <button onClick={this.handleCheckoutAddress} className="im-checkout-btn">PLACE ORDER</button>
                              
                          </div>
                        <div className="clearfix"></div>
                      </div> }
                    </div>
                    }
                </div>

                <Modal show={this.state.open} onHide={this.handleClose} bsSize="small" animation={false}>
                    <div className="modal-content">
                      <div className="modal-header">
                        <button type="button" onClick={this.handleClose} className="close" data-dismiss="modal">&times;</button>
                        <h5 className="modal-title">CHANGE QUANTITY</h5>
                      </div>
                      <div style={{maxHeight: 170, minHeight: 150, overflow: 'auto'}}>
                        <ul className="list-group">
                          {this.renderSizes()}
                        </ul>
                      </div>
                  </div>
                </Modal>


            </div> 
        );
    }
}

const mapStateToProps = (store) => {
    return {
        Products: store.getProducts.Products,
        cartCount: store.cart.cartCount,
        cartProducts: store.cart.cartProducts,
        liveCartItems: store.getProducts.liveCartItems,
        validatingCart: store.getProducts.validatingCart
    };
};

export default connect(mapStateToProps)(CheckoutCart)

